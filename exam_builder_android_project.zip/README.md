# منشئ الامتحانات (Flutter)

مشروع Flutter بواجهة Material 3. ملفات الأندرويد تُنشأ تلقائيًا داخل GitHub Actions (`flutter create`)
ثم تُضاف إليها صلاحيات التخزين، لذلك لا يوجد مجلد `android` هنا.
