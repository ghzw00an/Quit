package com.example.exambuilder

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.content.Context
import android.content.Intent
import android.widget.Toast
import android.print.PrintAttributes
import android.print.PrintManager

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var pendingDoc: String? = null
    private val REQ_SAVE_DOC = 1001

    inner class AndroidBridge {
        @JavascriptInterface
        fun saveDoc(html: String) {
            runOnUiThread {
                pendingDoc = html
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/msword"
                    putExtra(Intent.EXTRA_TITLE, "exam.doc")
                }
                startActivityForResult(intent, REQ_SAVE_DOC)
            }
        }

        @JavascriptInterface
        fun printPage() {
            runOnUiThread {
                val printManager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                val adapter = webView.createPrintDocumentAdapter("الامتحان")
                printManager.print(
                    "ورقة الامتحان",
                    adapter,
                    PrintAttributes.Builder().build()
                )
            }
        }
    }

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SAVE_DOC && resultCode == RESULT_OK) {
            val uri = data?.data
            val html = pendingDoc
            if (uri != null && html != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                        out.write(html.toByteArray(Charsets.UTF_8))
                    }
                    Toast.makeText(this, "تم حفظ الملف", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "تعذر حفظ الملف", Toast.LENGTH_LONG).show()
                }
            }
        }
        pendingDoc = null
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
