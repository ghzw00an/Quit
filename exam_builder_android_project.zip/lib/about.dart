import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'update.dart';
import 'ui.dart';

const String kShareText =
    'منشئ الامتحانات — برنامج مجاني لإعداد الأسئلة وطباعتها بحجم A4.\n'
    'تحميل التطبيق: $kReleasesUrl';

Future<void> shareApp() => Share.share(kShareText, subject: 'منشئ الامتحانات');

class AboutPage extends StatefulWidget {
  const AboutPage({super.key});
  @override
  State<AboutPage> createState() => _AboutPageState();
}

class _AboutPageState extends State<AboutPage> {
  bool checking = false;
  bool installing = false;
  double? progress;
  String? status;
  UpdateInfo? info;

  Future<void> _check() async {
    setState(() {
      checking = true;
      status = null;
      info = null;
    });
    try {
      final u = await fetchLatest();
      if (!mounted) return;
      setState(() {
        if (u.isNewer) {
          info = u;
          status = 'يوجد تحديث جديد (الإصدار ${u.build})';
        } else {
          status = 'أنت على أحدث إصدار (رقم $kBuild)';
        }
      });
    } catch (e) {
      if (mounted) setState(() => status = '$e');
    } finally {
      if (mounted) setState(() => checking = false);
    }
  }

  Future<void> _install() async {
    final u = info;
    if (u == null) return;
    setState(() {
      installing = true;
      progress = 0;
    });
    try {
      await downloadAndInstall(u, (p) {
        if (mounted) setState(() => progress = p);
      });
      if (mounted) setState(() => status = 'تم فتح شاشة التثبيت');
    } catch (e) {
      if (mounted) setState(() => status = '$e');
    } finally {
      if (mounted) setState(() => installing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final tt = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: const Text('حول التطبيق')),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Column(
                children: [
                  const CircleAvatar(radius: 34, child: Icon(Icons.school, size: 34)),
                  const SizedBox(height: 8),
                  Text('منشئ الامتحانات', style: tt.titleLarge),
                  Text('الإصدار $kAppVersion  (بناء $kBuild)'),
                ],
              ),
            ),
          ),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    const Icon(Icons.favorite_outline),
                    const SizedBox(width: 8),
                    Text('من نحن', style: tt.titleMedium),
                  ]),
                  const SizedBox(height: 10),
                  const Text(
                    'البرنامج مجاني إلى وجه الله تعالى، وقد صُمِّم بأيادٍ جهادية من أحد أبناء '
                    'الحشد الشعبي، نسأل الله التوفيق والسداد....\n\nمن النهروان',
                    style: TextStyle(height: 1.8),
                  ),
                ],
              ),
            ),
          ),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    const Icon(Icons.new_releases_outlined),
                    const SizedBox(width: 8),
                    Text('ما الجديد', style: tt.titleMedium),
                  ]),
                  const SizedBox(height: 6),
                  for (final r in kChangelog)
                    ExpansionTile(
                      tilePadding: EdgeInsets.zero,
                      initiallyExpanded: r == kChangelog.first,
                      title: Text('الإصدار ${r.version}  •  ${r.date}'),
                      children: [
                        for (final it in r.items)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 6),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('•  '),
                                Expanded(child: Text(it, style: const TextStyle(height: 1.5))),
                              ],
                            ),
                          ),
                      ],
                    ),
                ],
              ),
            ),
          ),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    const Icon(Icons.system_update_alt),
                    const SizedBox(width: 8),
                    Text('التحقق من التحديث', style: tt.titleMedium),
                  ]),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: (checking || installing) ? null : _check,
                    icon: const Icon(Icons.refresh),
                    label: const Text('تحقق من وجود تحديث'),
                  ),
                  if (checking)
                    const Padding(
                      padding: EdgeInsets.only(top: 12),
                      child: LinearProgressIndicator(),
                    ),
                  if (status != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Text(status!),
                    ),
                  if (info != null) ...[
                    if (info!.notes.trim().isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text(info!.notes, style: const TextStyle(fontSize: 12)),
                      ),
                    const SizedBox(height: 12),
                    FilledButton.tonalIcon(
                      onPressed: installing ? null : _install,
                      icon: const Icon(Icons.download),
                      label: const Text('تنزيل وتثبيت التحديث'),
                    ),
                    if (installing)
                      Padding(
                        padding: const EdgeInsets.only(top: 12),
                        child: LinearProgressIndicator(value: progress),
                      ),
                    const SizedBox(height: 8),
                    const Text(
                      'سيعرض أندرويد شاشة التثبيت. وإن طلب إذن «تثبيت التطبيقات المجهولة» فاسمح به لهذا التطبيق.',
                      style: TextStyle(fontSize: 11),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 6),
          OutlinedButton.icon(
            onPressed: () {
              tapFeedback();
              shareApp();
            },
            icon: const Icon(Icons.share),
            label: const Text('مشاركة التطبيق'),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}
