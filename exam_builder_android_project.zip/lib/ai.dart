import 'dart:convert';
import 'dart:io';
import 'models.dart';

const String _schemaDoc = '''
Question types and their "data" keys (all values are plain strings; use \\n between lines):
- normal: no data
- section: note (optional note text). A section heading such as "Grammar (30 marks)"; put the heading in prompt.
- parts: items = lines "part text || marks"
- mcq: items = lines "sentence with ____ for the blank || choice1, choice2, choice3 || correct choice (may be empty)"
- tf: items = one statement per line
- fill: items = one sentence per line
- why: items = one statement per line
- enumerate: items = one item per line
- definitions: items = one term per line
- match: left = lines, right = lines
- compare: col1, col2, col3 = headings; rows = one row label per line
- irab: items = one sentence per line (Arabic parsing)
- essay: items = one topic per line
- dictation: text = dictation text
- equation: equation
- quran: quote, source
- experiment: steps
- image: imageAlt (short description of the figure)
''';

String _mediaType(List<int> b) {
  if (b.length > 4 && b[0] == 0x89 && b[1] == 0x50) return 'image/png';
  if (b.length > 4 && b[0] == 0x52 && b[1] == 0x49) return 'image/webp';
  return 'image/jpeg';
}

class AiPart {
  final String? text;
  final String? mime;
  final String? b64;
  const AiPart.text(String t)
      : text = t,
        mime = null,
        b64 = null;
  const AiPart.image(String m, String d)
      : text = null,
        mime = m,
        b64 = d;
  bool get isImage => b64 != null;
}

Future<AiPart> _imagePart(String path) async {
  final bytes = await File(path).readAsBytes();
  return AiPart.image(_mediaType(bytes), base64Encode(bytes));
}

String _errMsg(String body) {
  try {
    final j = jsonDecode(body);
    final e = j is Map ? j['error'] : null;
    if (e is Map && e['message'] != null) return e['message'].toString();
    if (e is String) return e;
    if (j is List && j.isNotEmpty && j[0] is Map && j[0]['error'] is Map) {
      return j[0]['error']['message'].toString();
    }
  } catch (_) {}
  return body.length > 300 ? body.substring(0, 300) : body;
}

Future<dynamic> _http(String method, String url, Map<String, String> headers,
    {Object? body, int timeout = 180}) async {
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 30);
  try {
    final req = await client.openUrl(method, Uri.parse(url));
    headers.forEach(req.headers.set);
    if (body != null) {
      req.headers.set('content-type', 'application/json');
      req.add(utf8.encode(jsonEncode(body)));
    }
    final res = await req.close().timeout(Duration(seconds: timeout));
    final txt = await res.transform(utf8.decoder).join();
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw 'خطأ ${res.statusCode}: ${_errMsg(txt)}';
    }
    return jsonDecode(txt);
  } finally {
    client.close();
  }
}

String _openaiBase() {
  if (app.aiProvider == 'openai') return 'https://api.openai.com/v1';
  var u = app.customUrl.trim();
  while (u.endsWith('/')) {
    u = u.substring(0, u.length - 1);
  }
  return u;
}

void _needKey() {
  if (app.apiKey.trim().isEmpty) {
    throw 'أدخل مفتاح ${kProviderNames[app.aiProvider]} من الإعدادات أولاً';
  }
  if (app.aiModel.trim().isEmpty) throw 'اختر اسم النموذج من الإعدادات';
  if (app.aiProvider == 'custom' && app.customUrl.trim().isEmpty) {
    throw 'أدخل رابط المزود من الإعدادات';
  }
}

Future<String> callAI(List<AiPart> parts, {int maxTokens = 4096}) async {
  _needKey();
  final key = app.apiKey.trim();
  final model = app.aiModel.trim();
  switch (app.aiProvider) {
    case 'claude':
      final j = await _http(
        'POST',
        'https://api.anthropic.com/v1/messages',
        {'x-api-key': key, 'anthropic-version': '2023-06-01'},
        body: {
          'model': model,
          'max_tokens': maxTokens,
          'messages': [
            {
              'role': 'user',
              'content': [
                for (final p in parts)
                  if (p.isImage)
                    {
                      'type': 'image',
                      'source': {'type': 'base64', 'media_type': p.mime, 'data': p.b64},
                    }
                  else
                    {'type': 'text', 'text': p.text},
              ],
            }
          ],
        },
      );
      return (j['content'] as List)
          .where((e) => e['type'] == 'text')
          .map((e) => e['text'].toString())
          .join('\n');
    case 'gemini':
      final j = await _http(
        'POST',
        'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent',
        {'x-goog-api-key': key},
        body: {
          'contents': [
            {
              'parts': [
                for (final p in parts)
                  if (p.isImage)
                    {
                      'inline_data': {'mime_type': p.mime, 'data': p.b64},
                    }
                  else
                    {'text': p.text},
              ],
            }
          ],
          'generationConfig': {'maxOutputTokens': maxTokens + 4000},
        },
      );
      final cands = j['candidates'] as List?;
      if (cands == null || cands.isEmpty) throw 'لم يُرجع Gemini أي نتيجة (قد يكون المحتوى محجوبًا)';
      final ps = (cands[0]['content']?['parts'] as List?) ?? [];
      return ps.where((e) => e['text'] != null).map((e) => e['text'].toString()).join('\n');
    default: // openai + custom
      final official = app.aiProvider == 'openai';
      final j = await _http(
        'POST',
        '${_openaiBase()}/chat/completions',
        {'Authorization': 'Bearer $key'},
        body: {
          'model': model,
          if (official) 'max_completion_tokens': maxTokens + 8000 else 'max_tokens': maxTokens,
          'messages': [
            {
              'role': 'user',
              'content': [
                for (final p in parts)
                  if (p.isImage)
                    {
                      'type': 'image_url',
                      'image_url': {'url': 'data:${p.mime};base64,${p.b64}'},
                    }
                  else
                    {'type': 'text', 'text': p.text},
              ],
            }
          ],
        },
      );
      final ch = j['choices'] as List?;
      if (ch == null || ch.isEmpty) throw 'لم يُرجع المزود أي نتيجة';
      final c = ch[0]['message']?['content'];
      if (c is String) return c;
      if (c is List) return c.map((e) => e['text']?.toString() ?? '').join('\n');
      return '';
  }
}

/// يجلب أسماء النماذج المتاحة للمزود الحالي.
Future<List<String>> listModels() async {
  if (app.apiKey.trim().isEmpty) throw 'أدخل المفتاح أولاً';
  final key = app.apiKey.trim();
  List<String> out;
  switch (app.aiProvider) {
    case 'claude':
      final j = await _http('GET', 'https://api.anthropic.com/v1/models?limit=100',
          {'x-api-key': key, 'anthropic-version': '2023-06-01'}, timeout: 30);
      out = [for (final m in (j['data'] as List)) m['id'].toString()];
      break;
    case 'gemini':
      final j = await _http(
          'GET',
          'https://generativelanguage.googleapis.com/v1beta/models?pageSize=200',
          {'x-goog-api-key': key},
          timeout: 30);
      out = [
        for (final m in (j['models'] as List))
          if ((m['supportedGenerationMethods'] as List?)?.contains('generateContent') ?? true)
            m['name'].toString().replaceFirst('models/', ''),
      ];
      break;
    default:
      final j = await _http('GET', '${_openaiBase()}/models', {'Authorization': 'Bearer $key'},
          timeout: 30);
      out = [for (final m in (j['data'] as List)) m['id'].toString()];
  }
  out.sort();
  return out;
}

String _extractJson(String t) {
  final i1 = t.indexOf('{');
  final i2 = t.indexOf('[');
  var start = -1;
  if (i1 >= 0 && i2 >= 0) {
    start = i1 < i2 ? i1 : i2;
  } else {
    start = i1 >= 0 ? i1 : i2;
  }
  if (start < 0) throw 'لم يُرجع الذكاء الاصطناعي نتيجة مفهومة';
  final isObj = t[start] == '{';
  final end = t.lastIndexOf(isObj ? '}' : ']');
  if (end <= start) throw 'النتيجة غير مكتملة، حاول مرة أخرى';
  return t.substring(start, end + 1);
}

Future<String> aiOcr(String path) async {
  final r = await callAI([
    await _imagePart(path),
    const AiPart.text('Transcribe all the text in this image exactly as written. Keep the original '
        'language (Arabic or English), diacritics and line breaks. Output only the text, '
        'with no comments.'),
  ]);
  return r.trim();
}

Future<Map<String, dynamic>> aiImportQuestions(String path) async {
  final r = await callAI([
    await _imagePart(path),
    AiPart.text(
          'This image is an exam paper. Extract it into JSON for an exam-builder app.\n'
          'Return ONLY valid JSON (no markdown) with this shape:\n'
          '{"header":{"authority":"","school":"","schoolType":"","title":"","subtitle":"",'
          '"grade":"","subject":"","duration":"","date":""},'
          '"questions":[{"type":"<type>","prompt":"<question text>","marks":<number>,'
          '"lang":"ar or en","data":{...}}]}\n'
          '$_schemaDoc\n'
          'Rules: keep the original wording exactly; do not number the questions (numbering is '
          'automatic); put the question wording in "prompt"; choose the closest type; use '
          '"section" for headings/notes such as "answer only three questions"; marks = 0 if unknown.'),
  ], maxTokens: 8000);
  final j = jsonDecode(_extractJson(r));
  if (j is! Map<String, dynamic>) throw 'تنسيق غير متوقع';
  return j;
}

/// يطبّق نتيجة الاستيراد؛ يرجع عدد الأسئلة المضافة.
int applyImport(Map<String, dynamic> j, {required bool header}) {
  var n = 0;
  for (final e in (j['questions'] as List? ?? [])) {
    if (e is! Map) continue;
    final type = kTypes.any((t) => t.key == e['type']) ? e['type'] as String : 'normal';
    final data = <String, String>{};
    (e['data'] as Map? ?? {}).forEach((k, v) {
      data[k.toString()] = v is List ? v.join('\n') : (v?.toString() ?? '');
    });
    app.questions.add(Question(
      id: '${DateTime.now().microsecondsSinceEpoch}$n',
      type: type,
      prompt: e['prompt']?.toString() ?? '',
      marks: (e['marks'] as num?)?.toInt() ?? 0,
      lang: e['lang'] == 'en' ? 'en' : 'ar',
      data: data,
    ));
    n++;
  }
  if (header && j['header'] is Map) {
    final h = (j['header'] as Map).cast<String, dynamic>();
    String g(String k, String old) {
      final v = h[k]?.toString().trim() ?? '';
      return v.isEmpty ? old : v;
    }

    final m = app.meta;
    m.authority = g('authority', m.authority);
    m.school = g('school', m.school);
    m.schoolType = g('schoolType', m.schoolType);
    m.title = g('title', m.title);
    m.subtitle = g('subtitle', m.subtitle);
    m.grade = g('grade', m.grade);
    m.duration = g('duration', m.duration);
    m.date = g('date', m.date);
    final subj = h['subject']?.toString().trim() ?? '';
    if (subj.isNotEmpty) {
      m.subject = subj;
      for (final s in kSubjects) {
        if (s.label == subj) m.subjectKey = s.key;
      }
    }
  }
  return n;
}

String questionPlain(Question q) {
  final b = StringBuffer(q.prompt);
  q.data.forEach((k, v) {
    if (k == 'imagePath' || v.trim().isEmpty) return;
    b.write('\n[$k] $v');
  });
  return b.toString();
}

Future<List<String>> aiAnswers(List<Question> qs) async {
  final b = StringBuffer();
  for (var i = 0; i < qs.length; i++) {
    b.write('#$i (${qs[i].type}): ${questionPlain(qs[i])}\n\n');
  }
  final r = await callAI([
    AiPart.text(
          'Subject: ${app.meta.subject}. Grade: ${app.meta.grade}.\n'
          'Write a concise model answer for each exam question below, in the same language '
          'as the question. For multiple-choice give the correct choices; for true/false give '
          'صح/خطأ per statement; for headings (type section) return an empty string.\n'
          'Return ONLY a JSON array of strings, exactly ${qs.length} items, in order.\n\n$b'),
  ], maxTokens: 8000);
  final j = jsonDecode(_extractJson(r));
  if (j is! List) throw 'تنسيق غير متوقع';
  return [for (var i = 0; i < qs.length; i++) i < j.length ? j[i].toString() : ''];
}

Future<String> aiAnswerOne(Question q) async {
  final r = await aiAnswers([q]);
  return r.first;
}
