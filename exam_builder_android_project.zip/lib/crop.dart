import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'files.dart';

/// شاشة قص بسيطة: تسحب الأشرطة لتحديد المنطقة (مخطط / خريطة) من الصورة.
class CropPage extends StatefulWidget {
  final String path;
  const CropPage({super.key, required this.path});
  @override
  State<CropPage> createState() => _CropPageState();
}

class _CropPageState extends State<CropPage> {
  ui.Image? _img;
  RangeValues _h = const RangeValues(0, 1);
  RangeValues _v = const RangeValues(0, 1);
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final bytes = await File(widget.path).readAsBytes();
    final img = await decodeImageFromList(bytes);
    if (mounted) setState(() => _img = img);
  }

  Future<void> _crop() async {
    final img = _img;
    if (img == null) return;
    setState(() => _busy = true);
    try {
      final w = img.width.toDouble();
      final h = img.height.toDouble();
      final src = Rect.fromLTRB(_h.start * w, _v.start * h, _h.end * w, _v.end * h);
      final ow = src.width.round().clamp(1, 100000);
      final oh = src.height.round().clamp(1, 100000);
      final rec = ui.PictureRecorder();
      final canvas = Canvas(rec);
      canvas.drawImageRect(
          img, src, Rect.fromLTWH(0, 0, ow.toDouble(), oh.toDouble()), Paint());
      final out = await rec.endRecording().toImage(ow, oh);
      final bd = await out.toByteData(format: ui.ImageByteFormat.png);
      if (bd == null) return;
      final d = await getApplicationDocumentsDirectory();
      final dest = '${d.path}/crop_${stamp()}.png';
      await File(dest).writeAsBytes(bd.buffer.asUint8List());
      if (mounted) Navigator.pop(context, dest);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final img = _img;
    return Scaffold(
      appBar: AppBar(
        title: const Text('قص المخطط أو الخريطة'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, widget.path),
            child: const Text('الصورة كاملة'),
          ),
        ],
      ),
      body: img == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                AspectRatio(
                  aspectRatio: img.width / img.height,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.file(File(widget.path), fit: BoxFit.fill),
                      CustomPaint(painter: _CropPainter(_h, _v)),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                const Text('العرض (يمين / يسار)'),
                RangeSlider(
                  values: _h,
                  min: 0,
                  max: 1,
                  onChanged: (v) => setState(() => _h = v),
                ),
                const Text('الارتفاع (أعلى / أسفل)'),
                RangeSlider(
                  values: _v,
                  min: 0,
                  max: 1,
                  onChanged: (v) => setState(() => _v = v),
                ),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: _busy ? null : _crop,
                  icon: const Icon(Icons.crop),
                  label: const Text('اقتطاع واستخدام'),
                ),
              ],
            ),
    );
  }
}

class _CropPainter extends CustomPainter {
  final RangeValues h, v;
  _CropPainter(this.h, this.v);

  @override
  void paint(Canvas canvas, Size size) {
    final r = Rect.fromLTRB(
        h.start * size.width, v.start * size.height, h.end * size.width, v.end * size.height);
    final dim = Paint()..color = const Color(0x99000000);
    canvas.drawRect(Rect.fromLTRB(0, 0, size.width, r.top), dim);
    canvas.drawRect(Rect.fromLTRB(0, r.bottom, size.width, size.height), dim);
    canvas.drawRect(Rect.fromLTRB(0, r.top, r.left, r.bottom), dim);
    canvas.drawRect(Rect.fromLTRB(r.right, r.top, size.width, r.bottom), dim);
    canvas.drawRect(
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = Colors.amber);
  }

  @override
  bool shouldRepaint(covariant _CropPainter old) => old.h != h || old.v != v;
}
