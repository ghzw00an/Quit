import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:permission_handler/permission_handler.dart';
import 'models.dart';

String stamp() => DateTime.now().millisecondsSinceEpoch.toString();

/// يحفظ الملف في المجلد المختار، وإن تعذر يحفظه في مجلد التطبيق.
Future<String> saveFile(String name, List<int> bytes) async {
  Directory dir;
  if (app.saveDir != null) {
    dir = Directory(app.saveDir!);
  } else {
    dir = (await getExternalStorageDirectory()) ??
        await getApplicationDocumentsDirectory();
  }
  try {
    await dir.create(recursive: true);
    final f = File('${dir.path}/$name');
    await f.writeAsBytes(bytes);
    return f.path;
  } catch (_) {
    final d = await getApplicationDocumentsDirectory();
    final f = File('${d.path}/$name');
    await f.writeAsBytes(bytes);
    return f.path;
  }
}

Future<String?> pickImage() async {
  final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1600);
  if (x == null) return null;
  final d = await getApplicationDocumentsDirectory();
  final dest = '${d.path}/img_${stamp()}.png';
  await File(x.path).copy(dest);
  return dest;
}

Future<void> chooseFolder() async {
  try {
    await Permission.manageExternalStorage.request();
  } catch (_) {}
  final p = await FilePicker.platform.getDirectoryPath();
  if (p != null) {
    app.saveDir = p;
    app.changed();
  }
}

Future<bool> openExamFile() async {
  final r = await FilePicker.platform.pickFiles(type: FileType.any);
  final path = r?.files.single.path;
  if (path == null) return false;
  final txt = await File(path).readAsString();
  app.loadExam(jsonDecode(txt) as Map<String, dynamic>);
  app.changed();
  return true;
}

Future<Uint8List> buildPdf(List<Uint8List> pngs) async {
  final doc = pw.Document();
  for (final p in pngs) {
    final img = pw.MemoryImage(p);
    doc.addPage(pw.Page(
      pageFormat: PdfPageFormat.a4,
      margin: pw.EdgeInsets.zero,
      build: (c) => pw.SizedBox(
        width: PdfPageFormat.a4.width,
        height: PdfPageFormat.a4.height,
        child: pw.Image(img, fit: pw.BoxFit.fill),
      ),
    ));
  }
  return doc.save();
}

String _esc(String s) =>
    s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');

String _hex(int c) => '#${(c & 0xFFFFFF).toRadixString(16).padLeft(6, '0')}';

List<String> _ls(String s) =>
    s.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();

String examHtml() {
  final a = app;
  final m = a.meta;
  final hf = a.headerFmt;
  final bf = a.bodyFmt;
  final hs = 'font-size:${hf.size}px;color:${_hex(hf.color)};'
      'font-weight:${hf.bold ? 'bold' : 'normal'};'
      'text-decoration:${hf.underline ? 'underline' : 'none'};'
      'font-style:${hf.italic ? 'italic' : 'normal'}';
  final ps = 'font-size:${bf.size}px;color:${_hex(bf.color)};'
      'font-weight:${bf.bold ? 'bold' : 'normal'};'
      'text-decoration:${bf.underline ? 'underline' : 'none'};'
      'font-style:${bf.italic ? 'italic' : 'normal'}';
  final cs = 'font-size:${bf.size}px;color:${_hex(bf.color)}';
  final b = StringBuffer();
  b.write('<div style="text-align:center;border-bottom:2px solid #000">');
  b.write('<p style="$hs">${_esc(m.school.isEmpty ? 'اسم المدرسة' : m.school)}</p>');
  b.write('<p>امتحان ${_esc(m.subject)}</p>');
  b.write('<p>الصف: ${_esc(m.grade)} &nbsp;&nbsp; الزمن: ${_esc(m.duration)} &nbsp;&nbsp; الدرجة الكلية: ${_esc(m.total)}</p></div>');
  b.write('<p>اسم الطالب: ........................................</p>');
  for (var i = 0; i < a.questions.length; i++) {
    final q = a.questions[i];
    final d = q.data;
    final items = _ls(d['items'] ?? '');
    final dir = q.lang == 'en' ? 'ltr' : 'rtl';
    b.write('<div dir="$dir"><p style="$ps">${numLabel(a.numbering, i)} ${_esc(q.prompt)}'
        '${q.marks > 0 ? ' &nbsp; (${q.marks})' : ''}</p>');
    switch (q.type) {
      case 'definitions':
      case 'enumerate':
        for (var k = 0; k < items.length; k++) {
          b.write('<p style="$cs">${k + 1}- ${_esc(items[k])}</p>');
        }
        break;
      case 'tf':
        for (var k = 0; k < items.length; k++) {
          b.write('<p style="$cs">${k + 1}- ${_esc(items[k])} ( ........ )</p>');
        }
        break;
      case 'fill':
        for (var k = 0; k < items.length; k++) {
          b.write('<p style="$cs">${k + 1}- ${_esc(items[k])} ..............</p>');
        }
        break;
      case 'why':
        for (var k = 0; k < items.length; k++) {
          b.write('<p style="$cs">${k + 1}- ${_esc(items[k])}<br>.............................................</p>');
        }
        break;
      case 'mcq':
        final opts = (d['choices'] ?? '')
            .split(RegExp('[,،]'))
            .map((e) => e.trim())
            .where((e) => e.isNotEmpty)
            .map((e) => '( ${_esc(e)} )')
            .join(' &nbsp; ');
        b.write('<p style="$cs">$opts</p>');
        if (a.teacher && (d['correct'] ?? '').isNotEmpty) {
          b.write('<p style="color:green">الإجابة: ${_esc(d['correct']!)}</p>');
        }
        break;
      case 'compare':
        b.write('<table border="1" style="border-collapse:collapse;width:100%"><tr>'
            '<th>${_esc(d['col1'] ?? '')}</th><th>${_esc(d['col2'] ?? '')}</th><th>${_esc(d['col3'] ?? '')}</th></tr>');
        for (final r in _ls(d['rows'] ?? '')) {
          b.write('<tr><td>${_esc(r)}</td><td>&nbsp;</td><td>&nbsp;</td></tr>');
        }
        b.write('</table>');
        break;
      case 'match':
        final l = _ls(d['left'] ?? '');
        final r = _ls(d['right'] ?? '');
        final n = l.length > r.length ? l.length : r.length;
        b.write('<table border="1" style="border-collapse:collapse;width:100%">');
        for (var k = 0; k < n; k++) {
          b.write('<tr><td>${k + 1}- ${k < l.length ? _esc(l[k]) : ''}</td>'
              '<td>${k < r.length ? _esc(r[k]) : ''}</td></tr>');
        }
        b.write('</table>');
        break;
      case 'equation':
        b.write('<p style="text-align:center;$cs">${_esc(d['equation'] ?? '')}</p>');
        break;
      case 'quran':
        b.write('<p style="text-align:center;$cs">${_esc(d['quote'] ?? '')}</p>'
            '<p style="text-align:center">${_esc(d['source'] ?? '')}</p>');
        break;
      case 'experiment':
        b.write('<p style="$cs">${_esc(d['steps'] ?? '').replaceAll('\n', '<br>')}</p>');
        break;
      case 'image':
        b.write('<p style="$cs">${_esc(d['imageAlt'] ?? '')}</p>');
        break;
      default:
        b.write('<p>.....................................................</p>');
    }
    b.write('</div>');
  }
  return '<html dir="rtl"><head><meta charset="utf-8">'
      '<style>@page{size:21cm 29.7cm;margin:1.5cm}body{font-family:Arial}</style>'
      '</head><body>${b.toString()}</body></html>';
}

List<int> docBytes() => [0xEF, 0xBB, 0xBF, ...utf8.encode(examHtml())];
