import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';
import 'models.dart';

String stamp() => DateTime.now().millisecondsSinceEpoch.toString();

/// يحفظ الملف في المجلد المختار، وإن تعذر يحفظه في مجلد التطبيق.
Future<String> saveFile(String name, List<int> bytes) async {
  Directory dir;
  if (app.saveDir != null) {
    dir = Directory(app.saveDir!);
  } else {
    dir = (await getExternalStorageDirectory()) ??
        await getApplicationDocumentsDirectory();
  }
  try {
    await dir.create(recursive: true);
    final f = File('${dir.path}/$name');
    await f.writeAsBytes(bytes);
    return f.path;
  } catch (_) {
    final d = await getApplicationDocumentsDirectory();
    final f = File('${d.path}/$name');
    await f.writeAsBytes(bytes);
    return f.path;
  }
}

Future<String?> pickImageSrc(ImageSource src, {bool persist = true}) async {
  final x = await ImagePicker().pickImage(source: src, maxWidth: 1800, imageQuality: 90);
  if (x == null) return null;
  if (!persist) return x.path;
  final d = await getApplicationDocumentsDirectory();
  final dest = '${d.path}/img_${stamp()}.png';
  await File(x.path).copy(dest);
  return dest;
}

Future<String?> pickImage() => pickImageSrc(ImageSource.gallery);

Future<void> chooseFolder() async {
  try {
    await Permission.manageExternalStorage.request();
  } catch (_) {}
  final p = await FilePicker.platform.getDirectoryPath();
  if (p != null) {
    app.saveDir = p;
    app.changed();
  }
}

Future<bool> openExamFile() async {
  final r = await FilePicker.platform.pickFiles(type: FileType.any);
  final path = r?.files.single.path;
  if (path == null) return false;
  final txt = await File(path).readAsString();
  app.checkpoint();
  app.loadExam(jsonDecode(txt) as Map<String, dynamic>);
  app.changed();
  return true;
}

Future<Uint8List> buildPdf(List<Uint8List> pngs) async {
  final doc = pw.Document();
  for (final p in pngs) {
    final img = pw.MemoryImage(p);
    doc.addPage(pw.Page(
      pageFormat: PdfPageFormat.a4,
      margin: pw.EdgeInsets.zero,
      build: (c) => pw.SizedBox(
        width: PdfPageFormat.a4.width,
        height: PdfPageFormat.a4.height,
        child: pw.Image(img, fit: pw.BoxFit.fill),
      ),
    ));
  }
  return doc.save();
}

String _esc(String s) =>
    s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');

String _hex(int c) => '#${(c & 0xFFFFFF).toRadixString(16).padLeft(6, '0')}';

List<String> _ls(String s) =>
    s.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();

String examHtml() {
  final a = app;
  final m = a.meta;
  final hf = a.headerFmt;
  final bf = a.bodyFmt;
  String sty(TextFmt f) => 'font-size:${f.size}px;color:${_hex(f.color)};'
      'font-weight:${f.bold ? 'bold' : 'normal'};'
      'text-decoration:${f.underline ? 'underline' : 'none'};'
      'font-style:${f.italic ? 'italic' : 'normal'}';
  final hs = sty(hf);
  final ps = sty(bf);
  final cs = 'font-size:${bf.size}px;color:${_hex(bf.color)}';
  final b = StringBuffer();

  String cell(String t) => t.trim().isEmpty ? '' : '${_esc(t)}<br>';
  b.write('<table style="width:100%"><tr>'
      '<td style="width:30%;vertical-align:top">${cell(m.authority)}<b>${cell(m.school)}</b>${cell(m.schoolType)}</td>'
      '<td style="width:40%;text-align:center;vertical-align:top">${cell(m.bismillah)}'
      '<span style="$hs">${_esc(m.title)}</span><br>${cell(m.subtitle)}</td>'
      '<td style="width:30%;vertical-align:top">'
      '${m.grade.isEmpty ? '' : 'الصف / ${_esc(m.grade)}<br>'}'
      'المادة / ${_esc(m.subject)}<br>'
      '${m.duration.isEmpty ? '' : 'الزمن / ${_esc(m.duration)}<br>'}'
      '${m.date.isEmpty ? '' : 'التاريخ / ${_esc(m.date)}<br>'}'
      '${m.total.isEmpty ? '' : 'الدرجة / ${_esc(m.total)}'}</td></tr></table><hr>');

  var n = 0;
  for (final q in a.questions) {
    final d = q.data;
    final items = _ls(d['items'] ?? '');
    final dir = q.lang == 'en' ? 'ltr' : 'rtl';
    final marks = (a.showMarks && q.marks > 0) ? ' &nbsp; ( ${q.marks} )' : '';
    if (q.type == 'section') {
      final note = (d['note'] ?? '').trim();
      b.write('<p dir="$dir" style="$ps;text-decoration:underline">${_esc(q.prompt)}'
          '${note.isEmpty ? '' : ' : ملاحظة: ${_esc(note)}'}$marks</p>');
      continue;
    }
    final label = numLabel(a.numbering, n);
    n++;
    b.write('<div dir="$dir"><p style="$ps">$label ${_esc(q.prompt)}$marks</p>');
    switch (q.type) {
      case 'definitions':
      case 'enumerate':
        for (var k = 0; k < items.length; k++) {
          b.write('<p style="$cs">${k + 1}- ${_esc(items[k])}</p>');
        }
        break;
      case 'tf':
        for (var k = 0; k < items.length; k++) {
          b.write('<p style="$cs">${k + 1}- ${_esc(items[k])} ( ........ )</p>');
        }
        break;
      case 'fill':
      case 'irab':
        for (var k = 0; k < items.length; k++) {
          b.write('<p style="$cs">${k + 1}- ${_esc(items[k])} ..............</p>');
        }
        break;
      case 'why':
      case 'essay':
        for (var k = 0; k < items.length; k++) {
          b.write('<p style="$cs">${k + 1}- ${_esc(items[k])}<br>.............................................</p>');
        }
        break;
      case 'mcq':
        for (var k = 0; k < items.length; k++) {
          final r = parseRow(items[k], 3);
          final opts = r[1]
              .split(RegExp('[,،]'))
              .map((e) => e.trim())
              .where((e) => e.isNotEmpty)
              .map((e) => (a.teacher && e == r[2]) ? '<b>${_esc(e)}</b>' : _esc(e))
              .join(' ، ');
          b.write('<p style="$cs">${k + 1}- ${_esc(r[0])} ( $opts )</p>');
        }
        break;
      case 'parts':
        for (var k = 0; k < items.length; k++) {
          final r = parseRow(items[k], 2);
          b.write('<p style="$cs">${partLabel(k, q.lang == 'en')} ${_esc(r[0])}'
              '${r[1].isEmpty ? '' : ' ( ${_esc(r[1])} )'}</p>');
        }
        break;
      case 'compare':
        b.write('<table border="1" style="border-collapse:collapse;width:100%"><tr>'
            '<th>${_esc(d['col1'] ?? '')}</th><th>${_esc(d['col2'] ?? '')}</th><th>${_esc(d['col3'] ?? '')}</th></tr>');
        for (final r in _ls(d['rows'] ?? '')) {
          b.write('<tr><td>${_esc(r)}</td><td>&nbsp;</td><td>&nbsp;</td></tr>');
        }
        b.write('</table>');
        break;
      case 'match':
        final l = _ls(d['left'] ?? '');
        final r = _ls(d['right'] ?? '');
        final cnt = l.length > r.length ? l.length : r.length;
        b.write('<table border="1" style="border-collapse:collapse;width:100%">');
        for (var k = 0; k < cnt; k++) {
          b.write('<tr><td>${k + 1}- ${k < l.length ? _esc(l[k]) : ''}</td>'
              '<td>${k < r.length ? _esc(r[k]) : ''}</td></tr>');
        }
        b.write('</table>');
        break;
      case 'equation':
        b.write('<p style="text-align:center;$cs">${_esc(d['equation'] ?? '')}</p>');
        break;
      case 'quran':
        b.write('<p style="text-align:center;$cs">${_esc(d['quote'] ?? '')}</p>'
            '<p style="text-align:center">${_esc(d['source'] ?? '')}</p>');
        break;
      case 'experiment':
        b.write('<p style="$cs">${_esc(d['steps'] ?? '').replaceAll('\n', '<br>')}</p>');
        break;
      case 'image':
        b.write('<p style="$cs">${_esc(d['imageAlt'] ?? '')}</p>');
        break;
      default:
        b.write('<p>.....................................................</p>');
    }
    if (a.teacher && q.answer.trim().isNotEmpty) {
      b.write('<p style="color:#1B5E20">الإجابة النموذجية: ${_esc(q.answer)}</p>');
    }
    b.write('</div>');
  }
  if (m.wish.trim().isNotEmpty) {
    b.write('<p style="text-align:center;$hs">${_esc(m.wish)}</p>');
  }
  if (m.teacher.trim().isNotEmpty) {
    b.write('<p style="text-align:center">مدرس المادة: ${_esc(m.teacher)}</p>');
  }
  return '<html dir="rtl"><head><meta charset="utf-8">'
      '<style>@page{size:21cm 29.7cm;margin:1.5cm}body{font-family:Arial}</style>'
      '</head><body>${b.toString()}</body></html>';
}

List<int> docBytes() => [0xEF, 0xBB, 0xBF, ...utf8.encode(examHtml())];

// ───────────── المحفوظات ─────────────

class SavedExam {
  final File file;
  final String name, subject;
  final DateTime modified;
  final int count;
  SavedExam(this.file, this.name, this.subject, this.modified, this.count);
}

Future<List<Directory>> _libDirs() async {
  final out = <Directory>[];
  if (app.saveDir != null) out.add(Directory(app.saveDir!));
  final ext = await getExternalStorageDirectory();
  if (ext != null) out.add(ext);
  out.add(await getApplicationDocumentsDirectory());
  return out;
}

Future<List<SavedExam>> listSaved() async {
  final seen = <String>{};
  final res = <SavedExam>[];
  for (final d in await _libDirs()) {
    try {
      if (!await d.exists()) continue;
      for (final e in d.listSync()) {
        if (e is! File || !e.path.endsWith('.json')) continue;
        if (!seen.add(e.path)) continue;
        try {
          final j = jsonDecode(await e.readAsString());
          if (j is Map && j['questions'] is List) {
            final meta = (j['meta'] as Map?) ?? {};
            res.add(SavedExam(
              e,
              e.path.split('/').last.replaceAll('.json', ''),
              meta['subject']?.toString() ?? '',
              e.statSync().modified,
              (j['questions'] as List).length,
            ));
          }
        } catch (_) {}
      }
    } catch (_) {}
  }
  res.sort((x, y) => y.modified.compareTo(x.modified));
  return res;
}

Future<String> saveCurrentAs(String title) async {
  final safe = title
      .trim()
      .replaceAll(RegExp(r'[^\w\u0600-\u06FF ]'), '')
      .trim()
      .replaceAll(' ', '_');
  final name = '${safe.isEmpty ? 'exam' : safe}_${stamp()}.json';
  return saveFile(name, utf8.encode(jsonEncode(app.examJson())));
}

Future<void> loadSaved(SavedExam s) async {
  final j = jsonDecode(await s.file.readAsString()) as Map<String, dynamic>;
  app.checkpoint();
  app.loadExam(j);
  app.changed();
}

Future<void> shareSaved(SavedExam s) async {
  await Share.shareXFiles([XFile(s.file.path)], text: s.name);
}

Future<void> deleteSaved(SavedExam s) async {
  await s.file.delete();
}
