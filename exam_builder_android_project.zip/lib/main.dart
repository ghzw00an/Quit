import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:printing/printing.dart';
import 'about.dart';
import 'files.dart';
import 'update.dart';
import 'models.dart';
import 'paper.dart';
import 'ui.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await app.load();
  runApp(const ExamApp());
}

ThemeData buildTheme() {
  final seed = Color(app.seed);
  if (app.themeMode == 'dark') {
    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark),
    );
  }
  final cs = ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.light);
  if (app.themeMode == 'eye') {
    return ThemeData(
      useMaterial3: true,
      colorScheme: cs.copyWith(
        surface: const Color(0xFFF6EDD6),
        onSurface: const Color(0xFF3B3225),
      ),
      scaffoldBackgroundColor: const Color(0xFFF1E6C8),
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF1E6C8)),
    );
  }
  return ThemeData(useMaterial3: true, colorScheme: cs);
}

class ExamApp extends StatelessWidget {
  const ExamApp({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'منشئ الامتحانات',
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar'), Locale('en')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        theme: buildTheme(),
        home: const Home(),
      ),
    );
  }
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int tab = 0;
  GlobalKey<PaperPagesState> paperKey = GlobalKey<PaperPagesState>();
  bool busy = false;

  @override
  void initState() {
    super.initState();
    if (app.autoUpdate) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _silentCheck());
    }
  }

  Future<void> _silentCheck() async {
    try {
      final u = await fetchLatest();
      if (!mounted || !u.isNewer) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        duration: const Duration(seconds: 10),
        content: const Text('يوجد تحديث جديد للتطبيق'),
        action: SnackBarAction(
          label: 'تحديث',
          onPressed: () => Navigator.of(context).push(fancyRoute<void>(const AboutPage())),
        ),
      ));
    } catch (_) {}
  }

  static const titles = ['الامتحان', 'المعاينة (A4)', 'المحفوظات', 'الإعدادات'];

  Future<void> _pdf({required bool print}) async {
    final st = paperKey.currentState;
    if (st == null || busy) return;
    setState(() => busy = true);
    try {
      final pngs = await st.capture();
      if (pngs.isEmpty) {
        if (mounted) snack(context, 'لا توجد صفحات للتصدير');
        return;
      }
      final bytes = await buildPdf(pngs);
      if (print) {
        await Printing.layoutPdf(onLayout: (_) async => bytes, name: 'exam');
      } else {
        final p = await saveFile('exam_${stamp()}.pdf', bytes);
        if (mounted) snack(context, 'تم حفظ PDF: $p');
      }
    } catch (e) {
      if (mounted) snack(context, 'تعذر التصدير: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _word() async {
    try {
      final p = await saveFile('exam_${stamp()}.doc', docBytes());
      if (mounted) snack(context, 'تم حفظ Word: $p');
    } catch (e) {
      if (mounted) snack(context, 'تعذر الحفظ: $e');
    }
  }

  Future<void> _menu(String v) async {
    if (v == 'save') {
      final name = await askText(context, 'اسم الملف', app.meta.subject);
      if (name == null) return;
      final p = await saveCurrentAs(name);
      if (mounted) snack(context, 'تم حفظ الأسئلة: $p');
    } else if (v == 'open') {
      try {
        final ok = await openExamFile();
        if (ok && mounted) snack(context, 'تم فتح الامتحان');
      } catch (_) {
        if (mounted) snack(context, 'الملف غير صالح');
      }
    } else if (v == 'import') {
      await importFromImageFlow(context);
    } else if (v == 'answers') {
      await answersAllFlow(context);
    } else if (v == 'new') {
      final ok = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
          title: const Text('امتحان جديد'),
          content: const Text('سيتم مسح الامتحان الحالي (يمكنك التراجع بزر الرجوع). هل تريد المتابعة؟'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('مسح')),
          ],
        ),
      );
      if (ok == true) app.newExam();
    }
  }

  Future<void> _sharePdf() async {
    final st = paperKey.currentState;
    if (st == null || busy) return;
    setState(() => busy = true);
    try {
      final pngs = await st.capture();
      if (pngs.isEmpty) return;
      final bytes = await buildPdf(pngs);
      await Printing.sharePdf(bytes: bytes, filename: 'exam.pdf');
    } catch (e) {
      if (mounted) snack(context, 'تعذرت المشاركة: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Widget _preview() {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) => ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              FilledButton.icon(
                onPressed: busy ? null : () => _pdf(print: false),
                icon: const Icon(Icons.picture_as_pdf),
                label: const Text('حفظ PDF'),
              ),
              FilledButton.tonalIcon(
                onPressed: busy ? null : () => _pdf(print: true),
                icon: const Icon(Icons.print),
                label: const Text('طباعة'),
              ),
              FilledButton.tonalIcon(
                onPressed: busy ? null : _sharePdf,
                icon: const Icon(Icons.share),
                label: const Text('مشاركة'),
              ),
              FilledButton.tonalIcon(
                onPressed: _word,
                icon: const Icon(Icons.description),
                label: const Text('Word'),
              ),
              FilterChip(
                label: const Text('نسخة المدرس'),
                selected: app.teacher,
                onSelected: (v) {
                  app.teacher = v;
                  app.changed();
                },
              ),
            ],
          ),
          if (busy) const Padding(padding: EdgeInsets.only(top: 8), child: LinearProgressIndicator()),
          const SizedBox(height: 12),
          FittedBox(
            fit: BoxFit.fitWidth,
            child: PaperPages(key: paperKey, app: app),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const EditorTab(),
      _preview(),
      LibraryTab(onOpened: () => setState(() => tab = 0)),
      const SettingsTab(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Text(titles[tab]),
        actions: [
          ListenableBuilder(
            listenable: app,
            builder: (c, _) => Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (tab == 0) ...[
                  IconButton(
                    tooltip: 'تراجع',
                    icon: const Icon(Icons.undo),
                    onPressed: app.canUndo ? app.undo : null,
                  ),
                  IconButton(
                    tooltip: 'إعادة',
                    icon: const Icon(Icons.redo),
                    onPressed: app.canRedo ? app.redo : null,
                  ),
                ],
                PopupMenuButton<String>(
                  onSelected: _menu,
                  itemBuilder: (c) => const [
                    PopupMenuItem(value: 'import', child: Text('استيراد أسئلة من صورة (AI)')),
                    PopupMenuItem(value: 'answers', child: Text('توليد إجابات الأسئلة (AI)')),
                    PopupMenuItem(value: 'save', child: Text('حفظ الامتحان في المجلد')),
                    PopupMenuItem(value: 'open', child: Text('فتح ملف من الجهاز')),
                    PopupMenuItem(value: 'new', child: Text('امتحان جديد')),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 320),
        transitionBuilder: (child, anim) => FadeTransition(
          opacity: anim,
          child: SlideTransition(
            position: Tween<Offset>(begin: const Offset(0.04, 0), end: Offset.zero).animate(anim),
            child: child,
          ),
        ),
        child: KeyedSubtree(key: ValueKey(tab), child: pages[tab]),
      ),
      floatingActionButton: tab == 0
          ? Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                FloatingActionButton.small(
                  heroTag: 'fab-import',
                  tooltip: 'استيراد أسئلة من صورة',
                  onPressed: () => importFromImageFlow(context),
                  child: const Icon(Icons.document_scanner_outlined),
                ),
                const SizedBox(height: 10),
                FloatingActionButton.extended(
                  heroTag: 'fab-add',
                  onPressed: () => addQuestionFlow(context),
                  icon: const Icon(Icons.add),
                  label: const Text('إضافة سؤال'),
                ),
              ],
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() {
          if (i == 1) paperKey = GlobalKey<PaperPagesState>();
          tab = i;
        }),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.edit_note), label: 'الامتحان'),
          NavigationDestination(icon: Icon(Icons.description_outlined), label: 'المعاينة'),
          NavigationDestination(icon: Icon(Icons.folder_copy_outlined), label: 'المحفوظات'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'الإعدادات'),
        ],
      ),
    );
  }
}
