import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const List<int> kPalette = [
  0xFF111111, 0xFF1769AA, 0xFF0F9D91, 0xFFC62828,
  0xFF6A1B9A, 0xFFEF6C00, 0xFF2E7D32, 0xFF37474F,
];
const List<int> kSeeds = [
  0xFF1769AA, 0xFF0F9D91, 0xFF6A1B9A, 0xFFC62828,
  0xFFEF6C00, 0xFF2E7D32, 0xFF37474F, 0xFFAD1457,
];

class SubjectDef {
  final String key, label, icon;
  const SubjectDef(this.key, this.label, this.icon);
}

const List<SubjectDef> kSubjects = [
  SubjectDef('arabic', 'اللغة العربية', 'ع'),
  SubjectDef('english', 'اللغة الإنجليزية', 'En'),
  SubjectDef('history', 'التاريخ', '🏛️'),
  SubjectDef('geography', 'الجغرافيا', '🌍'),
  SubjectDef('biology', 'الأحياء', '🧬'),
  SubjectDef('physics', 'الفيزياء', '⚛️'),
  SubjectDef('islamic', 'التربية الإسلامية', '☪'),
  SubjectDef('chemistry', 'الكيمياء', '🧪'),
  SubjectDef('math', 'الرياضيات', '∑'),
  SubjectDef('general', 'جميع المواد', '＋'),
];

class TypeDef {
  final String key, label;
  final IconData icon;
  const TypeDef(this.key, this.label, this.icon);
}

const List<TypeDef> kTypes = [
  TypeDef('normal', 'سؤال عادي', Icons.edit_note),
  TypeDef('definitions', 'تعاريف', Icons.menu_book),
  TypeDef('tf', 'صح أو خطأ', Icons.rule),
  TypeDef('mcq', 'اختر الإجابة', Icons.checklist),
  TypeDef('compare', 'مقارنة', Icons.table_chart),
  TypeDef('match', 'صل بين العمودين', Icons.compare_arrows),
  TypeDef('fill', 'املأ الفراغات', Icons.border_color),
  TypeDef('why', 'علّل', Icons.help_outline),
  TypeDef('enumerate', 'عدّد', Icons.format_list_numbered),
  TypeDef('equation', 'معادلة / مسألة', Icons.functions),
  TypeDef('image', 'صورة / خريطة', Icons.image),
  TypeDef('quran', 'آية / حديث', Icons.auto_stories),
  TypeDef('experiment', 'تجربة مختبرية', Icons.science),
];

TypeDef typeOf(String key) =>
    kTypes.firstWhere((t) => t.key == key, orElse: () => kTypes.first);

class FieldDef {
  final String key, label, hint;
  final bool multiline;
  const FieldDef(this.key, this.label, this.multiline, [this.hint = '']);
}

const Map<String, List<FieldDef>> kFields = {
  'definitions': [FieldDef('items', 'المصطلحات (كل مصطلح في سطر)', true)],
  'tf': [FieldDef('items', 'العبارات (كل عبارة في سطر)', true)],
  'mcq': [
    FieldDef('choices', 'الاختيارات (افصل بينها بفاصلة)', false, 'مربع، دائري، مستطيل'),
    FieldDef('correct', 'الإجابة الصحيحة (تظهر في نسخة المدرس فقط)', false),
  ],
  'compare': [
    FieldDef('col1', 'عنوان العمود الأول', false, 'وجه المقارنة'),
    FieldDef('col2', 'عنوان العمود الثاني', false, 'المفهوم الأول'),
    FieldDef('col3', 'عنوان العمود الثالث', false, 'المفهوم الثاني'),
    FieldDef('rows', 'صفوف المقارنة (كل صف في سطر)', true),
  ],
  'match': [
    FieldDef('left', 'العمود الأول (كل عنصر في سطر)', true),
    FieldDef('right', 'العمود الثاني (كل عنصر في سطر)', true),
  ],
  'fill': [FieldDef('items', 'الجمل (كل جملة في سطر)', true)],
  'why': [FieldDef('items', 'العبارات (كل عبارة في سطر)', true)],
  'enumerate': [FieldDef('items', 'المطلوب تعداده (كل بند في سطر)', true)],
  'equation': [FieldDef('equation', 'المعادلة أو المسألة', true, 'H₂ + O₂ → H₂O')],
  'image': [FieldDef('imageAlt', 'وصف الصورة أو الخريطة', false)],
  'quran': [
    FieldDef('quote', 'نص الآية أو الحديث', true),
    FieldDef('source', 'المصدر / السورة / التخريج', false),
  ],
  'experiment': [FieldDef('steps', 'خطوات أو وصف التجربة', true)],
};

const List<String> _letters = ['أ', 'ب', 'ج', 'د', 'هـ', 'و', 'ز', 'ح', 'ط', 'ي'];

const Map<String, String> kNumberStyles = {
  'q': 'س1 /',
  'n': '1 -',
  'a': 'أ -',
  'e': 'Q1.',
};

String numLabel(String style, int i) {
  switch (style) {
    case 'n':
      return '${i + 1}-';
    case 'a':
      return i < _letters.length ? '${_letters[i]}-' : '${i + 1}-';
    case 'e':
      return 'Q${i + 1}.';
    default:
      return 'س${i + 1}/';
  }
}

class TextFmt {
  double size;
  int color;
  bool bold, underline, italic;
  TextFmt({
    this.size = 14,
    this.color = 0xFF111111,
    this.bold = true,
    this.underline = false,
    this.italic = false,
  });

  Map<String, dynamic> toJson() => {
        'size': size,
        'color': color,
        'bold': bold,
        'underline': underline,
        'italic': italic,
      };

  factory TextFmt.fromJson(Map<String, dynamic>? j, TextFmt d) {
    if (j == null) return d;
    return TextFmt(
      size: (j['size'] as num?)?.toDouble() ?? d.size,
      color: (j['color'] as num?)?.toInt() ?? d.color,
      bold: j['bold'] as bool? ?? d.bold,
      underline: j['underline'] as bool? ?? d.underline,
      italic: j['italic'] as bool? ?? d.italic,
    );
  }

  TextStyle prompt() => TextStyle(
        fontSize: size,
        color: Color(color),
        fontWeight: bold ? FontWeight.bold : FontWeight.normal,
        decoration: underline ? TextDecoration.underline : TextDecoration.none,
        fontStyle: italic ? FontStyle.italic : FontStyle.normal,
        height: 1.7,
      );

  TextStyle content() => TextStyle(
        fontSize: size,
        color: Color(color),
        fontWeight: FontWeight.normal,
        fontStyle: italic ? FontStyle.italic : FontStyle.normal,
        height: 1.7,
      );
}

class ExamMeta {
  String school, grade, subjectKey, subject, duration, total;
  String? logo;
  ExamMeta({
    this.school = '',
    this.grade = '',
    this.subjectKey = 'arabic',
    this.subject = 'اللغة العربية',
    this.duration = '',
    this.total = '100',
    this.logo,
  });

  Map<String, dynamic> toJson() => {
        'school': school,
        'grade': grade,
        'subjectKey': subjectKey,
        'subject': subject,
        'duration': duration,
        'total': total,
        'logo': logo,
      };

  factory ExamMeta.fromJson(Map<String, dynamic> j) => ExamMeta(
        school: j['school'] as String? ?? '',
        grade: j['grade'] as String? ?? '',
        subjectKey: j['subjectKey'] as String? ?? 'arabic',
        subject: j['subject'] as String? ?? 'اللغة العربية',
        duration: j['duration'] as String? ?? '',
        total: j['total'] as String? ?? '100',
        logo: j['logo'] as String?,
      );
}

class Question {
  String id, type, prompt, lang;
  int marks;
  Map<String, String> data;
  Question({
    required this.id,
    required this.type,
    this.prompt = '',
    this.marks = 5,
    this.lang = 'ar',
    Map<String, String>? data,
  }) : data = data ?? {};

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'prompt': prompt,
        'marks': marks,
        'lang': lang,
        'data': data,
      };

  factory Question.fromJson(Map<String, dynamic> j) => Question(
        id: j['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
        type: j['type'] as String? ?? 'normal',
        prompt: j['prompt'] as String? ?? '',
        marks: (j['marks'] as num?)?.toInt() ?? 0,
        lang: j['lang'] as String? ?? 'ar',
        data: ((j['data'] as Map?) ?? {})
            .map((k, v) => MapEntry(k.toString(), v?.toString() ?? '')),
      );

  Question clone() => Question(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        type: type,
        prompt: prompt,
        marks: marks,
        lang: lang,
        data: Map<String, String>.from(data),
      );
}

class AppState extends ChangeNotifier {
  ExamMeta meta = ExamMeta();
  List<Question> questions = [];
  TextFmt headerFmt = TextFmt(size: 20);
  TextFmt bodyFmt = TextFmt(size: 14);
  String numbering = 'q';
  bool teacher = false;

  String themeMode = 'light'; // light | dark | eye
  int seed = kSeeds[0];
  String? saveDir;

  SharedPreferences? _p;
  Timer? _t;

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    try {
      final s = _p!.getString('settings');
      if (s != null) {
        final j = jsonDecode(s) as Map<String, dynamic>;
        themeMode = j['themeMode'] as String? ?? 'light';
        seed = (j['seed'] as num?)?.toInt() ?? seed;
        saveDir = j['saveDir'] as String?;
      }
      final e = _p!.getString('exam');
      if (e != null) loadExam(jsonDecode(e) as Map<String, dynamic>);
    } catch (_) {}
  }

  Map<String, dynamic> examJson() => {
        'meta': meta.toJson(),
        'questions': questions.map((q) => q.toJson()).toList(),
        'headerFmt': headerFmt.toJson(),
        'bodyFmt': bodyFmt.toJson(),
        'numbering': numbering,
      };

  void loadExam(Map<String, dynamic> j) {
    meta = ExamMeta.fromJson(((j['meta'] as Map?) ?? {}).cast<String, dynamic>());
    questions = ((j['questions'] as List?) ?? [])
        .map((e) => Question.fromJson((e as Map).cast<String, dynamic>()))
        .toList();
    headerFmt = TextFmt.fromJson(
        (j['headerFmt'] as Map?)?.cast<String, dynamic>(), TextFmt(size: 20));
    bodyFmt = TextFmt.fromJson(
        (j['bodyFmt'] as Map?)?.cast<String, dynamic>(), TextFmt(size: 14));
    numbering = j['numbering'] as String? ?? 'q';
  }

  void newExam() {
    meta = ExamMeta();
    questions = [];
    changed();
  }

  void changed() {
    notifyListeners();
    _t?.cancel();
    _t = Timer(const Duration(milliseconds: 400), _persist);
  }

  Future<void> _persist() async {
    final p = _p;
    if (p == null) return;
    await p.setString('exam', jsonEncode(examJson()));
    await p.setString(
        'settings',
        jsonEncode({'themeMode': themeMode, 'seed': seed, 'saveDir': saveDir}));
  }
}

final AppState app = AppState();
