import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const Map<String, String> kProviderNames = {
  'claude': 'Claude (Anthropic)',
  'openai': 'ChatGPT (OpenAI)',
  'gemini': 'Gemini (Google)',
  'custom': 'مزود آخر (متوافق مع OpenAI)',
};

const Map<String, String> kDefaultModels = {
  'claude': 'claude-sonnet-5-5',
  'openai': 'gpt-5.5',
  'gemini': 'gemini-flash-latest',
  'custom': 'openrouter/auto',
};

/// إعدادات جاهزة للمزودين المتوافقين مع OpenAI: الاسم، الرابط، النموذج
const List<List<String>> kCustomPresets = [
  ['OpenRouter (نماذج متعددة)', 'https://openrouter.ai/api/v1', 'openrouter/auto'],
  ['Groq', 'https://api.groq.com/openai/v1', 'meta-llama/llama-4-scout-17b-16e-instruct'],
  ['DeepSeek (نصوص فقط)', 'https://api.deepseek.com/v1', 'deepseek-chat'],
  ['Mistral', 'https://api.mistral.ai/v1', 'pixtral-large-latest'],
];

const List<int> kPalette = [
  0xFF111111, 0xFF1769AA, 0xFF0F9D91, 0xFFC62828,
  0xFF6A1B9A, 0xFFEF6C00, 0xFF2E7D32, 0xFF37474F,
];
const List<int> kSeeds = [
  0xFF1769AA, 0xFF0F9D91, 0xFF6A1B9A, 0xFFC62828,
  0xFFEF6C00, 0xFF2E7D32, 0xFF37474F, 0xFFAD1457,
];

class SubjectDef {
  final String key, label, icon;
  const SubjectDef(this.key, this.label, this.icon);
}

const List<SubjectDef> kSubjects = [
  SubjectDef('arabic', 'اللغة العربية', 'ع'),
  SubjectDef('english', 'اللغة الإنجليزية', 'En'),
  SubjectDef('history', 'التاريخ', '🏛️'),
  SubjectDef('geography', 'الجغرافيا', '🌍'),
  SubjectDef('biology', 'الأحياء', '🧬'),
  SubjectDef('physics', 'الفيزياء', '⚛️'),
  SubjectDef('islamic', 'التربية الإسلامية', '☪'),
  SubjectDef('chemistry', 'الكيمياء', '🧪'),
  SubjectDef('math', 'الرياضيات', '∑'),
  SubjectDef('general', 'جميع المواد', '＋'),
];

class TypeDef {
  final String key, label;
  final IconData icon;
  const TypeDef(this.key, this.label, this.icon);
}

const List<TypeDef> kTypes = [
  TypeDef('section', 'عنوان قسم / ملاحظة', Icons.title),
  TypeDef('normal', 'سؤال عادي', Icons.edit_note),
  TypeDef('parts', 'فروع (أ، ب، ج) بدرجات', Icons.list_alt),
  TypeDef('irab', 'إعراب', Icons.spellcheck),
  TypeDef('essay', 'إنشاء / تعبير', Icons.article_outlined),
  TypeDef('dictation', 'إملاء', Icons.hearing),
  TypeDef('definitions', 'تعاريف', Icons.menu_book),
  TypeDef('tf', 'صح أو خطأ', Icons.rule),
  TypeDef('mcq', 'اختر الإجابة', Icons.checklist),
  TypeDef('compare', 'مقارنة', Icons.table_chart),
  TypeDef('match', 'صل بين العمودين', Icons.compare_arrows),
  TypeDef('fill', 'املأ الفراغات', Icons.border_color),
  TypeDef('why', 'علّل', Icons.help_outline),
  TypeDef('enumerate', 'عدّد', Icons.format_list_numbered),
  TypeDef('equation', 'معادلة / مسألة', Icons.functions),
  TypeDef('image', 'صورة / خريطة', Icons.image),
  TypeDef('quran', 'آية / حديث', Icons.auto_stories),
  TypeDef('experiment', 'تجربة مختبرية', Icons.science),
];

const List<String> _sci = [
  'section', 'normal', 'parts', 'mcq', 'tf', 'fill', 'why', 'definitions',
  'equation', 'experiment', 'image', 'compare', 'match', 'enumerate'
];

const Map<String, List<String>> kSubjectTypes = {
  'arabic': [
    'section', 'normal', 'parts', 'mcq', 'irab', 'fill', 'tf', 'definitions',
    'why', 'match', 'enumerate', 'quran', 'essay', 'dictation', 'image'
  ],
  'english': [
    'section', 'normal', 'parts', 'mcq', 'tf', 'fill', 'match', 'definitions',
    'essay', 'dictation', 'image'
  ],
  'math': ['section', 'normal', 'parts', 'mcq', 'tf', 'fill', 'equation', 'compare', 'image'],
  'physics': _sci,
  'chemistry': _sci,
  'biology': _sci,
  'history': [
    'section', 'normal', 'parts', 'mcq', 'tf', 'fill', 'why', 'definitions',
    'enumerate', 'match', 'compare', 'image'
  ],
  'geography': [
    'section', 'normal', 'parts', 'mcq', 'tf', 'fill', 'why', 'definitions',
    'enumerate', 'match', 'compare', 'image'
  ],
  'islamic': [
    'section', 'normal', 'parts', 'mcq', 'tf', 'fill', 'why', 'definitions',
    'quran', 'enumerate', 'match'
  ],
};

List<TypeDef> typesFor(String subjectKey) {
  final keys = kSubjectTypes[subjectKey];
  if (keys == null) return kTypes;
  return [for (final k in keys) typeOf(k)];
}

/// الأنواع التي تُحرَّر كصفوف (كل صف عدة حقول مفصولة بـ ||)
const Map<String, List<String>> kRows = {
  'mcq': ['الجملة (ضع ____ مكان الفراغ)', 'الاختيارات (افصل بينها بفاصلة)', 'الإجابة الصحيحة'],
  'parts': ['نص الفرع', 'الدرجة'],
};

List<String> parseRow(String line, int n) {
  final p = line.split('||').map((e) => e.trim()).toList();
  while (p.length < n) {
    p.add('');
  }
  return p;
}

TypeDef typeOf(String key) =>
    kTypes.firstWhere((t) => t.key == key, orElse: () => kTypes.first);

class FieldDef {
  final String key, label, hint;
  final bool multiline;
  const FieldDef(this.key, this.label, this.multiline, [this.hint = '']);
}

const Map<String, List<FieldDef>> kFields = {
  'definitions': [FieldDef('items', 'المصطلحات (كل مصطلح في سطر)', true)],
  'tf': [FieldDef('items', 'العبارات (كل عبارة في سطر)', true)],
  'section': [FieldDef('note', 'ملاحظة (مثل: الإجابة عن ثلاث أسئلة فقط)', false)],
  'irab': [FieldDef('items', 'الجمل المطلوب إعرابها (كل جملة في سطر)', true)],
  'essay': [FieldDef('items', 'المواضيع (كل موضوع في سطر)', true)],
  'dictation': [FieldDef('text', 'نص الإملاء (يظهر في نسخة المدرس فقط)', true)],
  'compare': [
    FieldDef('col1', 'عنوان العمود الأول', false, 'وجه المقارنة'),
    FieldDef('col2', 'عنوان العمود الثاني', false, 'المفهوم الأول'),
    FieldDef('col3', 'عنوان العمود الثالث', false, 'المفهوم الثاني'),
    FieldDef('rows', 'صفوف المقارنة (كل صف في سطر)', true),
  ],
  'match': [
    FieldDef('left', 'العمود الأول (كل عنصر في سطر)', true),
    FieldDef('right', 'العمود الثاني (كل عنصر في سطر)', true),
  ],
  'fill': [FieldDef('items', 'الجمل (كل جملة في سطر)', true)],
  'why': [FieldDef('items', 'العبارات (كل عبارة في سطر)', true)],
  'enumerate': [FieldDef('items', 'المطلوب تعداده (كل بند في سطر)', true)],
  'equation': [FieldDef('equation', 'المعادلة أو المسألة', true, 'H₂ + O₂ → H₂O')],
  'image': [FieldDef('imageAlt', 'وصف الصورة أو الخريطة', false)],
  'quran': [
    FieldDef('quote', 'نص الآية أو الحديث', true),
    FieldDef('source', 'المصدر / السورة / التخريج', false),
  ],
  'experiment': [FieldDef('steps', 'خطوات أو وصف التجربة', true)],
};

const List<String> _letters = ['أ', 'ب', 'ج', 'د', 'هـ', 'و', 'ز', 'ح', 'ط', 'ي'];

String partLabel(int i, bool en) {
  if (en) return '${String.fromCharCode(65 + i)}-';
  return i < _letters.length ? '${_letters[i]}-' : '${i + 1}-';
}

const Map<String, String> kNumberStyles = {
  'q': 'س1 /',
  'n': '1 -',
  'a': 'أ -',
  'e': 'Q1.',
};

String numLabel(String style, int i) {
  switch (style) {
    case 'n':
      return '${i + 1}-';
    case 'a':
      return i < _letters.length ? '${_letters[i]}-' : '${i + 1}-';
    case 'e':
      return 'Q${i + 1}.';
    default:
      return 'س${i + 1}/';
  }
}

class TextFmt {
  double size;
  int color;
  bool bold, underline, italic;
  TextFmt({
    this.size = 14,
    this.color = 0xFF111111,
    this.bold = true,
    this.underline = false,
    this.italic = false,
  });

  Map<String, dynamic> toJson() => {
        'size': size,
        'color': color,
        'bold': bold,
        'underline': underline,
        'italic': italic,
      };

  factory TextFmt.fromJson(Map<String, dynamic>? j, TextFmt d) {
    if (j == null) return d;
    return TextFmt(
      size: (j['size'] as num?)?.toDouble() ?? d.size,
      color: (j['color'] as num?)?.toInt() ?? d.color,
      bold: j['bold'] as bool? ?? d.bold,
      underline: j['underline'] as bool? ?? d.underline,
      italic: j['italic'] as bool? ?? d.italic,
    );
  }

  TextStyle prompt() => TextStyle(
        fontSize: size,
        color: Color(color),
        fontWeight: bold ? FontWeight.bold : FontWeight.normal,
        decoration: underline ? TextDecoration.underline : TextDecoration.none,
        fontStyle: italic ? FontStyle.italic : FontStyle.normal,
        height: 1.7,
      );

  TextStyle content() => TextStyle(
        fontSize: size,
        color: Color(color),
        fontWeight: FontWeight.normal,
        fontStyle: italic ? FontStyle.italic : FontStyle.normal,
        height: 1.7,
      );
}

class ExamMeta {
  String authority, school, schoolType, bismillah, title, subtitle;
  String grade, subjectKey, subject, duration, date, total, wish, teacher;
  String frame, watermark;
  double wmOpacity, wmSize;
  String? logo;
  ExamMeta({
    this.authority = '',
    this.school = '',
    this.schoolType = '',
    this.bismillah = 'بسم الله الرحمن الرحيم',
    this.title = 'أسئلة الامتحان',
    this.subtitle = '',
    this.grade = '',
    this.subjectKey = 'arabic',
    this.subject = 'اللغة العربية',
    this.duration = '',
    this.date = '',
    this.total = '',
    this.wish = 'مع تمنياتي لكم بالنجاح',
    this.teacher = '',
    this.frame = 'none',
    this.watermark = '',
    this.wmOpacity = 0.08,
    this.wmSize = 60,
    this.logo,
  });

  Map<String, dynamic> toJson() => {
        'authority': authority,
        'school': school,
        'schoolType': schoolType,
        'bismillah': bismillah,
        'title': title,
        'subtitle': subtitle,
        'grade': grade,
        'subjectKey': subjectKey,
        'subject': subject,
        'duration': duration,
        'date': date,
        'total': total,
        'wish': wish,
        'teacher': teacher,
        'frame': frame,
        'watermark': watermark,
        'wmOpacity': wmOpacity,
        'wmSize': wmSize,
        'logo': logo,
      };

  factory ExamMeta.fromJson(Map<String, dynamic> j) {
    final d = ExamMeta();
    return ExamMeta(
      authority: j['authority'] as String? ?? d.authority,
      school: j['school'] as String? ?? d.school,
      schoolType: j['schoolType'] as String? ?? d.schoolType,
      bismillah: j['bismillah'] as String? ?? d.bismillah,
      title: j['title'] as String? ?? d.title,
      subtitle: j['subtitle'] as String? ?? d.subtitle,
      grade: j['grade'] as String? ?? d.grade,
      subjectKey: j['subjectKey'] as String? ?? d.subjectKey,
      subject: j['subject'] as String? ?? d.subject,
      duration: j['duration'] as String? ?? d.duration,
      date: j['date'] as String? ?? d.date,
      total: j['total'] as String? ?? d.total,
      wish: j['wish'] as String? ?? d.wish,
      teacher: j['teacher'] as String? ?? d.teacher,
      frame: j['frame'] as String? ?? d.frame,
      watermark: j['watermark'] as String? ?? d.watermark,
      wmOpacity: (j['wmOpacity'] as num?)?.toDouble() ?? d.wmOpacity,
      wmSize: (j['wmSize'] as num?)?.toDouble() ?? d.wmSize,
      logo: j['logo'] as String?,
    );
  }
}

class Question {
  String id, type, prompt, lang, answer;
  int marks;
  Map<String, String> data;
  Question({
    required this.id,
    required this.type,
    this.prompt = '',
    this.marks = 5,
    this.lang = 'ar',
    this.answer = '',
    Map<String, String>? data,
  }) : data = data ?? {};

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'prompt': prompt,
        'marks': marks,
        'lang': lang,
        'answer': answer,
        'data': data,
      };

  factory Question.fromJson(Map<String, dynamic> j) => Question(
        id: j['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
        type: j['type'] as String? ?? 'normal',
        prompt: j['prompt'] as String? ?? '',
        marks: (j['marks'] as num?)?.toInt() ?? 0,
        lang: j['lang'] as String? ?? 'ar',
        answer: j['answer'] as String? ?? '',
        data: ((j['data'] as Map?) ?? {})
            .map((k, v) => MapEntry(k.toString(), v?.toString() ?? '')),
      );

  Question clone() => Question(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        type: type,
        prompt: prompt,
        marks: marks,
        lang: lang,
        answer: answer,
        data: Map<String, String>.from(data),
      );
}

class AppState extends ChangeNotifier {
  ExamMeta meta = ExamMeta();
  List<Question> questions = [];
  TextFmt headerFmt = TextFmt(size: 20);
  TextFmt bodyFmt = TextFmt(size: 14);
  String numbering = 'q';
  bool teacher = false;

  String themeMode = 'light'; // light | dark | eye
  int seed = kSeeds[0];
  String? saveDir;
  String aiProvider = 'claude'; // claude | openai | gemini | custom
  Map<String, String> aiKeys = {};
  Map<String, String> aiModels = Map<String, String>.from(kDefaultModels);
  String customUrl = 'https://openrouter.ai/api/v1';
  bool autoUpdate = true;

  String get apiKey => aiKeys[aiProvider] ?? '';
  String get aiModel => aiModels[aiProvider] ?? '';
  bool haptic = true;
  bool showMarks = true;
  bool pageNumbers = true;

  final List<String> _undo = [];
  final List<String> _redo = [];
  bool get canUndo => _undo.isNotEmpty;
  bool get canRedo => _redo.isNotEmpty;

  void checkpoint() {
    _undo.add(jsonEncode(examJson()));
    if (_undo.length > 30) _undo.removeAt(0);
    _redo.clear();
  }

  void undo() {
    if (_undo.isEmpty) return;
    _redo.add(jsonEncode(examJson()));
    loadExam(jsonDecode(_undo.removeLast()) as Map<String, dynamic>);
    changed();
  }

  void redo() {
    if (_redo.isEmpty) return;
    _undo.add(jsonEncode(examJson()));
    loadExam(jsonDecode(_redo.removeLast()) as Map<String, dynamic>);
    changed();
  }

  int numberOf(int idx) {
    if (questions[idx].type == 'section') return -1;
    var n = 0;
    for (var i = 0; i < idx; i++) {
      if (questions[i].type != 'section') n++;
    }
    return n;
  }

  SharedPreferences? _p;
  Timer? _t;

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    try {
      final s = _p!.getString('settings');
      if (s != null) {
        final j = jsonDecode(s) as Map<String, dynamic>;
        themeMode = j['themeMode'] as String? ?? 'light';
        seed = (j['seed'] as num?)?.toInt() ?? seed;
        saveDir = j['saveDir'] as String?;
        aiProvider = j['aiProvider'] as String? ?? 'claude';
        aiKeys = ((j['aiKeys'] as Map?) ?? {})
            .map((k, v) => MapEntry(k.toString(), v?.toString() ?? ''));
        final oldKey = j['apiKey'] as String?;
        if (oldKey != null && oldKey.isNotEmpty && (aiKeys['claude'] ?? '').isEmpty) {
          aiKeys['claude'] = oldKey;
        }
        ((j['aiModels'] as Map?) ?? {}).forEach((k, v) {
          if (v != null && v.toString().isNotEmpty) aiModels[k.toString()] = v.toString();
        });
        customUrl = j['customUrl'] as String? ?? customUrl;
        autoUpdate = j['autoUpdate'] as bool? ?? true;
        haptic = j['haptic'] as bool? ?? true;
        showMarks = j['showMarks'] as bool? ?? true;
        pageNumbers = j['pageNumbers'] as bool? ?? true;
      }
      final e = _p!.getString('exam');
      if (e != null) loadExam(jsonDecode(e) as Map<String, dynamic>);
    } catch (_) {}
  }

  Map<String, dynamic> examJson() => {
        'meta': meta.toJson(),
        'questions': questions.map((q) => q.toJson()).toList(),
        'headerFmt': headerFmt.toJson(),
        'bodyFmt': bodyFmt.toJson(),
        'numbering': numbering,
      };

  void loadExam(Map<String, dynamic> j) {
    meta = ExamMeta.fromJson(((j['meta'] as Map?) ?? {}).cast<String, dynamic>());
    questions = ((j['questions'] as List?) ?? [])
        .map((e) => Question.fromJson((e as Map).cast<String, dynamic>()))
        .toList();
    headerFmt = TextFmt.fromJson(
        (j['headerFmt'] as Map?)?.cast<String, dynamic>(), TextFmt(size: 20));
    bodyFmt = TextFmt.fromJson(
        (j['bodyFmt'] as Map?)?.cast<String, dynamic>(), TextFmt(size: 14));
    numbering = j['numbering'] as String? ?? 'q';
  }

  void newExam() {
    checkpoint();
    meta = ExamMeta();
    questions = [];
    changed();
  }

  void changed() {
    notifyListeners();
    _t?.cancel();
    _t = Timer(const Duration(milliseconds: 400), _persist);
  }

  Future<void> _persist() async {
    final p = _p;
    if (p == null) return;
    await p.setString('exam', jsonEncode(examJson()));
    await p.setString(
        'settings',
        jsonEncode({
          'themeMode': themeMode,
          'seed': seed,
          'saveDir': saveDir,
          'aiProvider': aiProvider,
          'aiKeys': aiKeys,
          'aiModels': aiModels,
          'customUrl': customUrl,
          'autoUpdate': autoUpdate,
          'haptic': haptic,
          'showMarks': showMarks,
          'pageNumbers': pageNumbers,
        }));
  }
}

final AppState app = AppState();
