import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'models.dart';

const double kPageW = 595, kPageH = 842, kPadH = 36, kPadV = 30, kFooterH = 20;
const double kContentW = kPageW - 2 * kPadH;
const double kContentH = kPageH - 2 * kPadV - kFooterH;
const String kDots = '..........................................................................';

List<String> splitLines(String s) =>
    s.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();

String defaultPrompt(String type, String lang) {
  final en = lang == 'en';
  switch (type) {
    case 'tf':
      return en ? 'Write (T) or (F):' : 'ضع علامة (صح) أو (خطأ) أمام العبارات الآتية:';
    case 'definitions':
      return en ? 'Define the following:' : 'عرّف ما يأتي:';
    case 'match':
      return en ? 'Match column A with column B:' : 'صل بين العمودين (أ) و (ب):';
    case 'fill':
      return en ? 'Complete the following:' : 'أكمل الفراغات الآتية:';
    case 'why':
      return en ? 'Give reasons:' : 'علّل لما يأتي:';
    case 'enumerate':
      return en ? 'List the following:' : 'عدّد ما يأتي:';
    default:
      return '';
  }
}

Widget _cell(String t, TextStyle s, {bool head = false}) => Padding(
      padding: const EdgeInsets.all(6),
      child: Text(t,
          textAlign: TextAlign.center,
          style: head ? s.copyWith(fontWeight: FontWeight.bold) : s),
    );

Widget headerBlock(AppState a) {
  final m = a.meta;
  final hf = a.headerFmt;
  final base = Color(hf.color);
  double sz(double d) => (hf.size - d) < 10 ? 10.0 : (hf.size - d);
  TextStyle st(double size, {bool bold = true}) => TextStyle(
      fontSize: size,
      color: base,
      fontWeight: bold ? FontWeight.bold : FontWeight.w500,
      height: 1.5);
  Widget line(String t, TextStyle s) =>
      t.trim().isEmpty ? const SizedBox.shrink() : Text(t, style: s);
  final hasLogo = m.logo != null && File(m.logo!).existsSync();

  final right = Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      if (hasLogo)
        Padding(
          padding: const EdgeInsets.only(bottom: 4),
          child: Image.file(File(m.logo!), height: 52, fit: BoxFit.contain),
        ),
      line(m.authority, st(sz(6))),
      line(m.school, hf.prompt().copyWith(fontSize: sz(4))),
      line(m.schoolType, st(sz(7))),
    ],
  );
  final center = Column(
    children: [
      line(m.bismillah, st(sz(5))),
      const SizedBox(height: 4),
      Text(m.title,
          textAlign: TextAlign.center,
          style: hf.prompt().copyWith(fontSize: hf.size)),
      line(m.subtitle, st(sz(6))),
    ],
  );
  final left = Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      line(m.grade.isEmpty ? '' : 'الصف / ${m.grade}', st(sz(7))),
      line('المادة / ${m.subject}', st(sz(7))),
      line(m.duration.isEmpty ? '' : 'الزمن / ${m.duration}', st(sz(7))),
      line(m.date.isEmpty ? '' : 'التاريخ / ${m.date}', st(sz(7))),
      line(m.total.isEmpty ? '' : 'الدرجة / ${m.total}', st(sz(7))),
    ],
  );
  return Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Column(
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(flex: 3, child: right),
            Expanded(flex: 4, child: center),
            Expanded(flex: 3, child: left),
          ],
        ),
        const Divider(color: Colors.black54, thickness: 1, height: 16),
      ],
    ),
  );
}

Widget? endBlock(AppState a) {
  final m = a.meta;
  if (m.wish.trim().isEmpty && m.teacher.trim().isEmpty) return null;
  final st = a.headerFmt.prompt().copyWith(fontSize: 14);
  return Padding(
    padding: const EdgeInsets.only(top: 14, bottom: 4),
    child: Column(
      children: [
        if (m.wish.trim().isNotEmpty)
          Text(m.wish, textAlign: TextAlign.center, style: st),
        if (m.teacher.trim().isNotEmpty) ...[
          const SizedBox(height: 6),
          Text('مدرس المادة: ${m.teacher}', textAlign: TextAlign.center, style: st),
        ],
      ],
    ),
  );
}

Widget _mcqRow(int i, List<String> r, TextStyle cs, bool teacher) {
  final opts = r[1]
      .split(RegExp('[,،]'))
      .map((e) => e.trim())
      .where((e) => e.isNotEmpty)
      .toList();
  const okStyle = TextStyle(
      fontWeight: FontWeight.bold,
      color: Color(0xFF1B5E20),
      decoration: TextDecoration.underline);
  final spans = <InlineSpan>[TextSpan(text: '${i + 1}- ${r[0]}  ( ')];
  for (var k = 0; k < opts.length; k++) {
    if (k > 0) spans.add(const TextSpan(text: ' ، '));
    final ok = teacher && r[2].isNotEmpty && opts[k] == r[2];
    spans.add(TextSpan(text: opts[k], style: ok ? okStyle : null));
  }
  spans.add(const TextSpan(text: ' )'));
  if (teacher && r[2].isNotEmpty && !opts.contains(r[2])) {
    spans.add(TextSpan(text: '  ← ${r[2]}', style: okStyle));
  }
  return Padding(
    padding: const EdgeInsets.only(bottom: 2),
    child: Text.rich(TextSpan(style: cs, children: spans)),
  );
}

List<Widget> _body(Question q, TextStyle cs, bool teacher) {
  final d = q.data;
  final en = q.lang == 'en';
  final items = splitLines(d['items'] ?? '');
  switch (q.type) {
    case 'definitions':
      return [
        Wrap(spacing: 16, children: [
          for (var i = 0; i < items.length; i++)
            Text('${i + 1}- ${items[i]}.', style: cs),
        ])
      ];
    case 'tf':
      return [
        for (var i = 0; i < items.length; i++)
          Text('${i + 1}- ${items[i]}   (  ............  )', style: cs)
      ];
    case 'mcq':
      final mrows = splitLines(d['items'] ?? '').map((l) => parseRow(l, 3)).toList();
      return [for (var i = 0; i < mrows.length; i++) _mcqRow(i, mrows[i], cs, teacher)];
    case 'parts':
      final prows = splitLines(d['items'] ?? '').map((l) => parseRow(l, 2)).toList();
      return [
        for (var i = 0; i < prows.length; i++)
          Text(
              '${partLabel(i, en)} ${prows[i][0]}'
              '${prows[i][1].isEmpty ? '' : '   ( ${prows[i][1]} ${en ? 'marks' : 'درجات'} )'}',
              style: cs)
      ];
    case 'irab':
      return [
        for (var i = 0; i < items.length; i++)
          Text('${i + 1}- ${items[i]} : ..........................', style: cs)
      ];
    case 'essay':
      return [
        for (var i = 0; i < items.length; i++) Text('${i + 1}- ${items[i]}', style: cs),
        for (var i = 0; i < 3; i++)
          Text(kDots, maxLines: 1, overflow: TextOverflow.clip, style: cs),
      ];
    case 'dictation':
      return [
        for (var i = 0; i < 5; i++)
          Text(kDots, maxLines: 1, overflow: TextOverflow.clip, style: cs),
        if (teacher && (d['text'] ?? '').trim().isNotEmpty)
          Text(d['text']!, style: cs.copyWith(color: const Color(0xFF1B5E20))),
      ];
    case 'compare':
      final rows = splitLines(d['rows'] ?? '');
      final c1 = (d['col1'] ?? '').isEmpty ? 'وجه المقارنة' : d['col1']!;
      final c2 = (d['col2'] ?? '').isEmpty ? 'المفهوم الأول' : d['col2']!;
      final c3 = (d['col3'] ?? '').isEmpty ? 'المفهوم الثاني' : d['col3']!;
      return [
        Table(
          border: TableBorder.all(color: Colors.black87),
          children: [
            TableRow(
              decoration: const BoxDecoration(color: Color(0xFFEEEEEE)),
              children: [_cell(c1, cs, head: true), _cell(c2, cs, head: true), _cell(c3, cs, head: true)],
            ),
            for (final r in rows)
              TableRow(children: [_cell(r, cs), _cell('', cs), _cell('', cs)]),
          ],
        )
      ];
    case 'match':
      final l = splitLines(d['left'] ?? '');
      final r = splitLines(d['right'] ?? '');
      final n = l.length > r.length ? l.length : r.length;
      const arLetters = ['أ', 'ب', 'ج', 'د', 'هـ', 'و', 'ز', 'ح', 'ط', 'ي'];
      String letter(int i) => en
          ? String.fromCharCode(65 + i)
          : (i < arLetters.length ? arLetters[i] : '${i + 1}');
      return [
        Table(
          border: TableBorder.all(color: Colors.black87),
          children: [
            TableRow(
              decoration: const BoxDecoration(color: Color(0xFFEEEEEE)),
              children: [
                _cell(en ? 'Column A' : 'العمود (أ)', cs, head: true),
                _cell(en ? 'Column B' : 'العمود (ب)', cs, head: true),
              ],
            ),
            for (var i = 0; i < n; i++)
              TableRow(children: [
                _cell('${i + 1}- ${i < l.length ? l[i] : ''}', cs),
                _cell('${letter(i)}- ${i < r.length ? r[i] : ''}', cs),
              ]),
          ],
        )
      ];
    case 'fill':
      return [
        for (var i = 0; i < items.length; i++)
          Text('${i + 1}- ${items[i]} ....................', style: cs)
      ];
    case 'why':
      return [
        for (var i = 0; i < items.length; i++) ...[
          Text('${i + 1}- ${items[i]}', style: cs),
          Text(kDots, maxLines: 1, overflow: TextOverflow.clip, style: cs),
        ]
      ];
    case 'enumerate':
      return [
        for (var i = 0; i < items.length; i++) Text('${i + 1}- ${items[i]} .', style: cs)
      ];
    case 'equation':
      return [
        Center(
          child: Text(d['equation'] ?? '',
              textAlign: TextAlign.center,
              style: cs.copyWith(fontSize: (cs.fontSize ?? 14) + 3)),
        )
      ];
    case 'image':
      final p = d['imagePath'];
      return [
        if (p != null && File(p).existsSync())
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Image.file(File(p), height: 200, fit: BoxFit.contain),
            ),
          ),
        if ((d['imageAlt'] ?? '').isNotEmpty) Text(d['imageAlt']!, style: cs),
      ];
    case 'quran':
      return [
        Center(
          child: Text(d['quote'] ?? '',
              textAlign: TextAlign.center,
              style: cs.copyWith(fontSize: (cs.fontSize ?? 14) + 2)),
        ),
        if ((d['source'] ?? '').isNotEmpty)
          Center(child: Text(d['source']!, style: cs.copyWith(fontSize: 11))),
      ];
    case 'experiment':
      return [Text(d['steps'] ?? '', style: cs)];
    default:
      return [
        Text(kDots, maxLines: 1, overflow: TextOverflow.clip, style: cs),
        Text(kDots, maxLines: 1, overflow: TextOverflow.clip, style: cs),
      ];
  }
}

Widget questionBlock(AppState a, Question q, String label) {
  final ps = a.bodyFmt.prompt();
  final cs = a.bodyFmt.content();
  final en = q.lang == 'en';
  final dir = en ? TextDirection.ltr : TextDirection.rtl;
  final marksTxt = (a.showMarks && q.marks > 0)
      ? '  ( ${q.marks} ${en ? 'marks' : 'درجة'} )'
      : '';

  if (q.type == 'section') {
    final note = (q.data['note'] ?? '').trim();
    final txt = '${q.prompt}${note.isEmpty ? '' : ' : ${en ? 'Note' : 'ملاحظة'}: $note'}$marksTxt';
    return Directionality(
      textDirection: dir,
      child: Padding(
        padding: const EdgeInsets.only(top: 4, bottom: 10),
        child: Text(txt, style: ps.copyWith(decoration: TextDecoration.underline)),
      ),
    );
  }

  final text = q.prompt.isEmpty ? defaultPrompt(q.type, q.lang) : q.prompt;
  final showAns = a.teacher && q.answer.trim().isNotEmpty;
  return Directionality(
    textDirection: dir,
    child: Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('$label ', style: ps),
              Expanded(child: Text('$text$marksTxt', style: ps)),
            ],
          ),
          ..._body(q, cs, a.teacher),
          if (showAns)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.only(top: 4),
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: const Color(0xFFE8F5E9),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text('${en ? 'Answer' : 'الإجابة النموذجية'}: ${q.answer}',
                  style: const TextStyle(fontSize: 12, color: Color(0xFF1B5E20), height: 1.5)),
            ),
        ],
      ),
    ),
  );
}

List<Widget> buildBlocks(AppState a) {
  final blocks = <Widget>[headerBlock(a)];
  var n = 0;
  for (final q in a.questions) {
    var label = '';
    if (q.type != 'section') {
      label = numLabel(a.numbering, n);
      n++;
    }
    blocks.add(questionBlock(a, q, label));
  }
  final end = endBlock(a);
  if (end != null) blocks.add(end);
  return blocks;
}

class PaperPages extends StatefulWidget {
  final AppState app;
  const PaperPages({super.key, required this.app});
  @override
  State<PaperPages> createState() => PaperPagesState();
}

class PaperPagesState extends State<PaperPages> {
  List<GlobalKey> _mKeys = [];
  List<GlobalKey> _pageKeys = [];
  List<List<int>> _pages = [];

  int get pageCount => _pages.length;

  void _measure() {
    if (!mounted) return;
    final hs = <double>[];
    for (final k in _mKeys) {
      final h = k.currentContext?.size?.height;
      if (h == null) return;
      hs.add(h);
    }
    final pages = <List<int>>[];
    var cur = <int>[];
    var used = 0.0;
    for (var i = 0; i < hs.length; i++) {
      if (cur.isNotEmpty && used + hs[i] > kContentH) {
        pages.add(cur);
        cur = <int>[];
        used = 0;
      }
      cur.add(i);
      used += hs[i];
    }
    if (cur.isNotEmpty) pages.add(cur);
    if (pages.toString() != _pages.toString()) {
      setState(() => _pages = pages);
    }
  }

  Future<List<Uint8List>> capture() async {
    await Future.delayed(const Duration(milliseconds: 120));
    final out = <Uint8List>[];
    for (final k in _pageKeys) {
      final ro = k.currentContext?.findRenderObject();
      if (ro is! RenderRepaintBoundary) continue;
      final img = await ro.toImage(pixelRatio: 3);
      final bd = await img.toByteData(format: ui.ImageByteFormat.png);
      if (bd != null) out.add(bd.buffer.asUint8List());
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    final a = widget.app;
    final blocks = buildBlocks(a);
    if (_mKeys.length != blocks.length) {
      _mKeys = List.generate(blocks.length, (_) => GlobalKey());
    }
    if (_pageKeys.length != _pages.length) {
      _pageKeys = List.generate(_pages.length, (_) => GlobalKey());
    }
    WidgetsBinding.instance.addPostFrameCallback((_) => _measure());

    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.noScaling),
      child: DefaultTextStyle(
        style: const TextStyle(color: Colors.black, fontSize: 14),
        child: Stack(
          children: [
            Offstage(
              child: SizedBox(
                width: kContentW,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    for (var i = 0; i < blocks.length; i++)
                      KeyedSubtree(key: _mKeys[i], child: blocks[i]),
                  ],
                ),
              ),
            ),
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (var p = 0; p < _pages.length; p++) _page(p, blocks),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _frame(String f) {
    switch (f) {
      case 'double':
        return Container(
          decoration: BoxDecoration(border: Border.all(width: 2.5)),
          child: Padding(
            padding: const EdgeInsets.all(3),
            child: Container(decoration: BoxDecoration(border: Border.all(width: 0.8))),
          ),
        );
      case 'round':
        return Container(
          decoration: BoxDecoration(
            border: Border.all(width: 1.6),
            borderRadius: BorderRadius.circular(18),
          ),
        );
      case 'thick':
        return Container(decoration: BoxDecoration(border: Border.all(width: 4)));
      default:
        return Container(decoration: BoxDecoration(border: Border.all(width: 1.2)));
    }
  }

  Widget _page(int pi, List<Widget> blocks) {
    final a = widget.app;
    final m = a.meta;
    return Container(
      margin: const EdgeInsets.only(bottom: 18),
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(color: Color(0x33000000), blurRadius: 10)],
      ),
      child: RepaintBoundary(
        key: _pageKeys[pi],
        child: Container(
          width: kPageW,
          height: kPageH,
          color: Colors.white,
          child: Stack(
            children: [
              if (m.frame != 'none')
                Positioned.fill(
                  child: Padding(padding: const EdgeInsets.all(12), child: _frame(m.frame)),
                ),
              if (m.watermark.trim().isNotEmpty)
                Positioned.fill(
                  child: Center(
                    child: Transform.rotate(
                      angle: -0.6,
                      child: SizedBox(
                        width: 480,
                        child: Text(
                          m.watermark,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: m.wmSize,
                            fontWeight: FontWeight.bold,
                            color: Colors.black.withAlpha((m.wmOpacity * 255).round()),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: kPadH, vertical: kPadV),
                child: Column(
                  children: [
                    Expanded(
                      child: SingleChildScrollView(
                        physics: const NeverScrollableScrollPhysics(),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [for (final idx in _pages[pi]) blocks[idx]],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: kFooterH,
                      child: Center(
                        child: a.pageNumbers
                            ? Text('${pi + 1} / ${_pages.length}',
                                style: const TextStyle(fontSize: 10, color: Colors.black54))
                            : const SizedBox.shrink(),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
