import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'models.dart';

const double kPageW = 595, kPageH = 842, kPadH = 36, kPadV = 30, kFooterH = 20;
const double kContentW = kPageW - 2 * kPadH;
const double kContentH = kPageH - 2 * kPadV - kFooterH;
const String kDots = '..........................................................................';

List<String> splitLines(String s) =>
    s.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();

String defaultPrompt(String type, String lang) {
  final en = lang == 'en';
  switch (type) {
    case 'tf':
      return en ? 'Write (T) or (F):' : 'ضع علامة (صح) أو (خطأ) أمام العبارات الآتية:';
    case 'definitions':
      return en ? 'Define the following:' : 'عرّف ما يأتي:';
    case 'match':
      return en ? 'Match column A with column B:' : 'صل بين العمودين (أ) و (ب):';
    case 'fill':
      return en ? 'Complete the following:' : 'أكمل الفراغات الآتية:';
    case 'why':
      return en ? 'Give reasons:' : 'علّل لما يأتي:';
    case 'enumerate':
      return en ? 'List the following:' : 'عدّد ما يأتي:';
    default:
      return '';
  }
}

Widget _cell(String t, TextStyle s, {bool head = false}) => Padding(
      padding: const EdgeInsets.all(6),
      child: Text(t,
          textAlign: TextAlign.center,
          style: head ? s.copyWith(fontWeight: FontWeight.bold) : s),
    );

Widget headerBlock(AppState a) {
  final m = a.meta;
  final hf = a.headerFmt;
  final small = TextStyle(
      fontSize: 12, color: Color(hf.color), fontWeight: FontWeight.w600);
  final subSize = hf.size - 4 < 11 ? 11.0 : hf.size - 4;
  final sub = TextStyle(
      fontSize: subSize, color: Color(hf.color), fontWeight: FontWeight.w600);
  final hasLogo = m.logo != null && File(m.logo!).existsSync();
  return Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Column(
      children: [
        if (hasLogo)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Image.file(File(m.logo!), height: 64, fit: BoxFit.contain),
          ),
        Text(m.school.isEmpty ? 'اسم المدرسة' : m.school,
            textAlign: TextAlign.center, style: hf.prompt()),
        const SizedBox(height: 4),
        Text('امتحان ${m.subject}', style: sub),
        const SizedBox(height: 6),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('الصف: ${m.grade.isEmpty ? '—' : m.grade}', style: small),
            Text('الزمن: ${m.duration.isEmpty ? '—' : m.duration}', style: small),
            Text('الدرجة الكلية: ${m.total}', style: small),
          ],
        ),
        const SizedBox(height: 6),
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: Text('اسم الطالب: ............................................   الرقم: ..........',
              style: small),
        ),
        const SizedBox(height: 4),
        const Divider(color: Colors.black, thickness: 1.5, height: 10),
      ],
    ),
  );
}

List<Widget> _body(Question q, TextStyle cs, bool teacher) {
  final d = q.data;
  final en = q.lang == 'en';
  final items = splitLines(d['items'] ?? '');
  switch (q.type) {
    case 'definitions':
      return [
        Wrap(spacing: 16, children: [
          for (var i = 0; i < items.length; i++)
            Text('${i + 1}- ${items[i]}.', style: cs),
        ])
      ];
    case 'tf':
      return [
        for (var i = 0; i < items.length; i++)
          Text('${i + 1}- ${items[i]}   (  ............  )', style: cs)
      ];
    case 'mcq':
      final opts = (d['choices'] ?? '')
          .split(RegExp('[,،]'))
          .map((e) => e.trim())
          .where((e) => e.isNotEmpty)
          .toList();
      return [
        Wrap(spacing: 14, children: [for (final o in opts) Text('( $o )', style: cs)]),
        if (teacher && (d['correct'] ?? '').trim().isNotEmpty)
          Text('الإجابة النموذجية: ${d['correct']}',
              style: cs.copyWith(color: const Color(0xFF1B5E20), fontWeight: FontWeight.bold)),
      ];
    case 'compare':
      final rows = splitLines(d['rows'] ?? '');
      final c1 = (d['col1'] ?? '').isEmpty ? 'وجه المقارنة' : d['col1']!;
      final c2 = (d['col2'] ?? '').isEmpty ? 'المفهوم الأول' : d['col2']!;
      final c3 = (d['col3'] ?? '').isEmpty ? 'المفهوم الثاني' : d['col3']!;
      return [
        Table(
          border: TableBorder.all(color: Colors.black87),
          children: [
            TableRow(
              decoration: const BoxDecoration(color: Color(0xFFEEEEEE)),
              children: [_cell(c1, cs, head: true), _cell(c2, cs, head: true), _cell(c3, cs, head: true)],
            ),
            for (final r in rows)
              TableRow(children: [_cell(r, cs), _cell('', cs), _cell('', cs)]),
          ],
        )
      ];
    case 'match':
      final l = splitLines(d['left'] ?? '');
      final r = splitLines(d['right'] ?? '');
      final n = l.length > r.length ? l.length : r.length;
      const arLetters = ['أ', 'ب', 'ج', 'د', 'هـ', 'و', 'ز', 'ح', 'ط', 'ي'];
      String letter(int i) => en
          ? String.fromCharCode(65 + i)
          : (i < arLetters.length ? arLetters[i] : '${i + 1}');
      return [
        Table(
          border: TableBorder.all(color: Colors.black87),
          children: [
            TableRow(
              decoration: const BoxDecoration(color: Color(0xFFEEEEEE)),
              children: [
                _cell(en ? 'Column A' : 'العمود (أ)', cs, head: true),
                _cell(en ? 'Column B' : 'العمود (ب)', cs, head: true),
              ],
            ),
            for (var i = 0; i < n; i++)
              TableRow(children: [
                _cell('${i + 1}- ${i < l.length ? l[i] : ''}', cs),
                _cell('${letter(i)}- ${i < r.length ? r[i] : ''}', cs),
              ]),
          ],
        )
      ];
    case 'fill':
      return [
        for (var i = 0; i < items.length; i++)
          Text('${i + 1}- ${items[i]} ....................', style: cs)
      ];
    case 'why':
      return [
        for (var i = 0; i < items.length; i++) ...[
          Text('${i + 1}- ${items[i]}', style: cs),
          Text(kDots, maxLines: 1, overflow: TextOverflow.clip, style: cs),
        ]
      ];
    case 'enumerate':
      return [
        for (var i = 0; i < items.length; i++) Text('${i + 1}- ${items[i]} .', style: cs)
      ];
    case 'equation':
      return [
        Center(
          child: Text(d['equation'] ?? '',
              textAlign: TextAlign.center,
              style: cs.copyWith(fontSize: (cs.fontSize ?? 14) + 3)),
        )
      ];
    case 'image':
      final p = d['imagePath'];
      return [
        if (p != null && File(p).existsSync())
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Image.file(File(p), height: 200, fit: BoxFit.contain),
            ),
          ),
        if ((d['imageAlt'] ?? '').isNotEmpty) Text(d['imageAlt']!, style: cs),
      ];
    case 'quran':
      return [
        Center(
          child: Text(d['quote'] ?? '',
              textAlign: TextAlign.center,
              style: cs.copyWith(fontSize: (cs.fontSize ?? 14) + 2)),
        ),
        if ((d['source'] ?? '').isNotEmpty)
          Center(child: Text(d['source']!, style: cs.copyWith(fontSize: 11))),
      ];
    case 'experiment':
      return [Text(d['steps'] ?? '', style: cs)];
    default:
      return [
        Text(kDots, maxLines: 1, overflow: TextOverflow.clip, style: cs),
        Text(kDots, maxLines: 1, overflow: TextOverflow.clip, style: cs),
      ];
  }
}

Widget questionBlock(AppState a, Question q, int i) {
  final ps = a.bodyFmt.prompt();
  final cs = a.bodyFmt.content();
  final label = numLabel(a.numbering, i);
  final text = q.prompt.isEmpty ? defaultPrompt(q.type, q.lang) : q.prompt;
  return Directionality(
    textDirection: q.lang == 'en' ? TextDirection.ltr : TextDirection.rtl,
    child: Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('$label ', style: ps),
              Expanded(child: Text(text, style: ps)),
              if (q.marks > 0)
                Text('  (${q.marks} ${q.lang == 'en' ? 'marks' : 'درجات'})',
                    style: const TextStyle(fontSize: 11, color: Colors.black87)),
            ],
          ),
          ..._body(q, cs, a.teacher),
        ],
      ),
    ),
  );
}

class PaperPages extends StatefulWidget {
  final AppState app;
  const PaperPages({super.key, required this.app});
  @override
  State<PaperPages> createState() => PaperPagesState();
}

class PaperPagesState extends State<PaperPages> {
  List<GlobalKey> _mKeys = [];
  List<GlobalKey> _pageKeys = [];
  List<List<int>> _pages = [];

  int get pageCount => _pages.length;

  void _measure() {
    if (!mounted) return;
    final hs = <double>[];
    for (final k in _mKeys) {
      final h = k.currentContext?.size?.height;
      if (h == null) return;
      hs.add(h);
    }
    final pages = <List<int>>[];
    var cur = <int>[];
    var used = 0.0;
    for (var i = 0; i < hs.length; i++) {
      if (cur.isNotEmpty && used + hs[i] > kContentH) {
        pages.add(cur);
        cur = <int>[];
        used = 0;
      }
      cur.add(i);
      used += hs[i];
    }
    if (cur.isNotEmpty) pages.add(cur);
    if (pages.toString() != _pages.toString()) {
      setState(() => _pages = pages);
    }
  }

  Future<List<Uint8List>> capture() async {
    await Future.delayed(const Duration(milliseconds: 120));
    final out = <Uint8List>[];
    for (final k in _pageKeys) {
      final ro = k.currentContext?.findRenderObject();
      if (ro is! RenderRepaintBoundary) continue;
      final img = await ro.toImage(pixelRatio: 3);
      final bd = await img.toByteData(format: ui.ImageByteFormat.png);
      if (bd != null) out.add(bd.buffer.asUint8List());
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    final a = widget.app;
    final blocks = <Widget>[
      headerBlock(a),
      for (var i = 0; i < a.questions.length; i++) questionBlock(a, a.questions[i], i),
    ];
    if (_mKeys.length != blocks.length) {
      _mKeys = List.generate(blocks.length, (_) => GlobalKey());
    }
    if (_pageKeys.length != _pages.length) {
      _pageKeys = List.generate(_pages.length, (_) => GlobalKey());
    }
    WidgetsBinding.instance.addPostFrameCallback((_) => _measure());

    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.noScaling),
      child: DefaultTextStyle(
        style: const TextStyle(color: Colors.black, fontSize: 14),
        child: Stack(
          children: [
            Offstage(
              child: SizedBox(
                width: kContentW,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    for (var i = 0; i < blocks.length; i++)
                      KeyedSubtree(key: _mKeys[i], child: blocks[i]),
                  ],
                ),
              ),
            ),
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (var p = 0; p < _pages.length; p++) _page(p, blocks),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _page(int pi, List<Widget> blocks) {
    return Container(
      margin: const EdgeInsets.only(bottom: 18),
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(color: Color(0x33000000), blurRadius: 10)],
      ),
      child: RepaintBoundary(
        key: _pageKeys[pi],
        child: Container(
          width: kPageW,
          height: kPageH,
          color: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: kPadH, vertical: kPadV),
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  physics: const NeverScrollableScrollPhysics(),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [for (final idx in _pages[pi]) blocks[idx]],
                  ),
                ),
              ),
              SizedBox(
                height: kFooterH,
                child: Center(
                  child: Text('${pi + 1} / ${_pages.length}',
                      style: const TextStyle(fontSize: 10, color: Colors.black54)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
