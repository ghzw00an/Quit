import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'about.dart';
import 'ai.dart';
import 'crop.dart';
import 'files.dart';
import 'models.dart';

void snack(BuildContext c, String m) {
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));
}

void tapFeedback() {
  if (app.haptic) HapticFeedback.selectionClick();
}

Route<T> fancyRoute<T>(Widget page) => PageRouteBuilder<T>(
      transitionDuration: const Duration(milliseconds: 320),
      pageBuilder: (c, a, s) => page,
      transitionsBuilder: (c, a, s, child) => FadeTransition(
        opacity: a,
        child: SlideTransition(
          position: Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
              .chain(CurveTween(curve: Curves.easeOutCubic))
              .animate(a),
          child: child,
        ),
      ),
    );

Future<T?> withProgress<T>(
    BuildContext context, String msg, Future<T> Function() job) async {
  showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (c) => PopScope(
      canPop: false,
      child: AlertDialog(
        content: Row(
          children: [
            const CircularProgressIndicator(),
            const SizedBox(width: 16),
            Expanded(child: Text(msg)),
          ],
        ),
      ),
    ),
  );
  try {
    return await job();
  } catch (e) {
    if (context.mounted) snack(context, '$e');
    return null;
  } finally {
    if (context.mounted) Navigator.of(context, rootNavigator: true).pop();
  }
}

Future<ImageSource?> chooseSource(BuildContext context) {
  return showModalBottomSheet<ImageSource>(
    context: context,
    showDragHandle: true,
    builder: (c) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.photo_camera),
            title: const Text('الكاميرا'),
            onTap: () => Navigator.pop(c, ImageSource.camera),
          ),
          ListTile(
            leading: const Icon(Icons.photo_library),
            title: const Text('المعرض'),
            onTap: () => Navigator.pop(c, ImageSource.gallery),
          ),
        ],
      ),
    ),
  );
}

Future<String?> askText(BuildContext context, String title, String initial) {
  final c = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(controller: c, autofocus: true),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: const Text('موافق')),
      ],
    ),
  );
}

// ───────────────────────── تدفقات الأسئلة ─────────────────────────

Future<void> addQuestionFlow(BuildContext context) async {
  final types = typesFor(app.meta.subjectKey);
  final type = await showModalBottomSheet<String>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (c) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('أنواع أسئلة ${app.meta.subject}',
                style: Theme.of(c).textTheme.titleMedium),
            const SizedBox(height: 12),
            Flexible(
              child: GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.05,
                children: [
                  for (final t in types)
                    _Tile(
                      label: t.label,
                      child: Icon(t.icon, size: 28),
                      onTap: () => Navigator.pop(c, t.key),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
  if (type == null || !context.mounted) return;
  final q = await Navigator.of(context).push<Question>(fancyRoute<Question>(
    QuestionEditor(question: Question(id: stamp(), type: type, marks: type == 'section' ? 0 : 5)),
  ));
  if (q != null) {
    app.checkpoint();
    app.questions.add(q);
    app.changed();
  }
}

Future<void> editQuestionFlow(BuildContext context, int i) async {
  final q = await Navigator.of(context).push<Question>(
      fancyRoute<Question>(QuestionEditor(question: app.questions[i])));
  if (q != null) {
    app.checkpoint();
    app.questions[i] = q;
    app.changed();
  }
}

Future<void> importFromImageFlow(BuildContext context) async {
  final src = await chooseSource(context);
  if (src == null) return;
  final path = await pickImageSrc(src, persist: false);
  if (path == null || !context.mounted) return;
  final j = await withProgress<Map<String, dynamic>>(
      context, 'جاري قراءة الصورة واستخراج الأسئلة...', () => aiImportQuestions(path));
  if (j == null || !context.mounted) return;
  final count = (j['questions'] as List? ?? []).length;
  if (count == 0) {
    snack(context, 'لم يتم العثور على أسئلة في الصورة');
    return;
  }
  var withHeader = true;
  final ok = await showDialog<bool>(
    context: context,
    builder: (c) => StatefulBuilder(
      builder: (c, setS) => AlertDialog(
        title: const Text('تم استخراج الأسئلة'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('عدد الأسئلة: $count — يمكنك تعديلها وترتيبها بعد الإضافة.'),
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              value: withHeader,
              onChanged: (v) => setS(() => withHeader = v ?? true),
              title: const Text('تحديث بيانات الترويسة أيضًا'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('إضافة')),
        ],
      ),
    ),
  );
  if (ok == true) {
    app.checkpoint();
    final n = applyImport(j, header: withHeader);
    app.changed();
    if (context.mounted) snack(context, 'تمت إضافة $n سؤال');
  }
}

Future<void> answersAllFlow(BuildContext context) async {
  final qs = app.questions;
  if (qs.isEmpty) {
    snack(context, 'أضف أسئلة أولاً');
    return;
  }
  final ans = await withProgress<List<String>>(
      context, 'جاري توليد الإجابات النموذجية...', () => aiAnswers(qs));
  if (ans == null) return;
  app.checkpoint();
  for (var i = 0; i < qs.length && i < ans.length; i++) {
    qs[i].answer = ans[i];
  }
  app.teacher = true;
  app.changed();
  if (context.mounted) snack(context, 'تم توليد الإجابات — تظهر في «نسخة المدرس»');
}

// ───────────────────────── عناصر مشتركة ─────────────────────────

class _Tile extends StatelessWidget {
  final String label;
  final Widget child;
  final VoidCallback onTap;
  const _Tile({required this.label, required this.child, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      color: cs.secondaryContainer,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          tapFeedback();
          onTap();
        },
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              child,
              const SizedBox(height: 6),
              Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}

Future<void> pickSubject(BuildContext context) async {
  final s = await showModalBottomSheet<SubjectDef>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (c) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('اختر المادة', style: Theme.of(c).textTheme.titleMedium),
            const SizedBox(height: 12),
            Flexible(
              child: GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.05,
                children: [
                  for (final sub in kSubjects)
                    _Tile(
                      label: sub.label,
                      child: Text(sub.icon, style: const TextStyle(fontSize: 26)),
                      onTap: () => Navigator.pop(c, sub),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
  if (s != null) {
    app.meta.subjectKey = s.key;
    app.meta.subject = s.label;
    app.changed();
  }
}

void openFormatSheet(BuildContext context) {
  int group = 0;
  showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (c) => StatefulBuilder(
      builder: (c, setS) => ListenableBuilder(
        listenable: app,
        builder: (c, _) {
          final f = group == 0 ? app.headerFmt : app.bodyFmt;
          final minS = group == 0 ? 14.0 : 10.0;
          final maxS = group == 0 ? 36.0 : 26.0;
          final size = f.size < minS ? minS : (f.size > maxS ? maxS : f.size);
          return SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SegmentedButton<int>(
                    segments: const [
                      ButtonSegment(value: 0, label: Text('الترويسة')),
                      ButtonSegment(value: 1, label: Text('الأسئلة')),
                    ],
                    selected: {group},
                    onSelectionChanged: (s) => setS(() => group = s.first),
                  ),
                  const SizedBox(height: 14),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.black12),
                    ),
                    child: Text('نص تجريبي — Sample', style: f.prompt()),
                  ),
                  const SizedBox(height: 12),
                  Text('حجم الخط: ${size.round()}'),
                  Slider(
                    min: minS,
                    max: maxS,
                    divisions: (maxS - minS).round(),
                    value: size,
                    onChanged: (v) {
                      f.size = v;
                      app.changed();
                    },
                  ),
                  const Text('اللون'),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      for (final col in kPalette)
                        GestureDetector(
                          onTap: () {
                            f.color = col;
                            app.changed();
                          },
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            width: 36,
                            height: 36,
                            decoration: BoxDecoration(
                              color: Color(col),
                              shape: BoxShape.circle,
                              border: Border.all(
                                width: f.color == col ? 3 : 1,
                                color: f.color == col ? Colors.amber : Colors.black26,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Wrap(
                    spacing: 8,
                    children: [
                      FilterChip(
                        label: const Text('غامق'),
                        selected: f.bold,
                        onSelected: (v) {
                          f.bold = v;
                          app.changed();
                        },
                      ),
                      FilterChip(
                        label: const Text('تحته خط'),
                        selected: f.underline,
                        onSelected: (v) {
                          f.underline = v;
                          app.changed();
                        },
                      ),
                      FilterChip(
                        label: const Text('مائل'),
                        selected: f.italic,
                        onSelected: (v) {
                          f.italic = v;
                          app.changed();
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    ),
  );
}

void openDesignSheet(BuildContext context) {
  final wm = TextEditingController(text: app.meta.watermark);
  showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (c) => ListenableBuilder(
      listenable: app,
      builder: (c, _) {
        final m = app.meta;
        return SafeArea(
          child: Padding(
            padding: EdgeInsets.fromLTRB(20, 0, 20, 20 + MediaQuery.of(c).viewInsets.bottom),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('إطار الورقة'),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: [
                      for (final e in const {
                        'none': 'بدون',
                        'line': 'خط',
                        'double': 'مزدوج',
                        'round': 'مستدير',
                        'thick': 'عريض',
                      }.entries)
                        ChoiceChip(
                          label: Text(e.value),
                          selected: m.frame == e.key,
                          onSelected: (_) {
                            m.frame = e.key;
                            app.changed();
                          },
                        ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: wm,
                    onChanged: (v) {
                      m.watermark = v;
                      app.changed();
                    },
                    decoration: const InputDecoration(
                      labelText: 'العلامة المائية (وسط الصفحة)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text('حجم العلامة: ${m.wmSize.round()}'),
                  Slider(
                    min: 24,
                    max: 110,
                    value: m.wmSize,
                    onChanged: (v) {
                      m.wmSize = v;
                      app.changed();
                    },
                  ),
                  Text('الشفافية: ${(m.wmOpacity * 100).round()}%'),
                  Slider(
                    min: 0.03,
                    max: 0.4,
                    value: m.wmOpacity,
                    onChanged: (v) {
                      m.wmOpacity = v;
                      app.changed();
                    },
                  ),
                ],
              ),
            ),
          ),
        );
      },
    ),
  );
}

class _MetaField extends StatefulWidget {
  final String label;
  final String initial;
  final ValueChanged<String> onChanged;
  final TextInputType? keyboard;
  final Widget? suffix;
  const _MetaField({
    super.key,
    required this.label,
    required this.initial,
    required this.onChanged,
    this.keyboard,
    this.suffix,
  });
  @override
  State<_MetaField> createState() => _MetaFieldState();
}

class _MetaFieldState extends State<_MetaField> {
  late final TextEditingController c = TextEditingController(text: widget.initial);
  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => TextField(
        controller: c,
        keyboardType: widget.keyboard,
        onChanged: widget.onChanged,
        decoration: InputDecoration(
          labelText: widget.label,
          suffixIcon: widget.suffix,
          border: const OutlineInputBorder(),
          isDense: true,
        ),
      );
}

// ───────────────────────── المحرر ─────────────────────────

class EditorTab extends StatelessWidget {
  const EditorTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final m = app.meta;
        final hasLogo = m.logo != null && File(m.logo!).existsSync();

        Widget f(String id, String label, String value, void Function(String) set,
            {TextInputType? kb}) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _MetaField(
              key: ValueKey(id),
              label: label,
              initial: value,
              keyboard: kb,
              onChanged: (v) {
                set(v);
                app.changed();
              },
            ),
          );
        }

        final header = Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
          child: Column(
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('ترويسة الامتحان', style: Theme.of(context).textTheme.titleMedium),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Container(
                            width: 64,
                            height: 64,
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.black26),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            clipBehavior: Clip.antiAlias,
                            child: hasLogo
                                ? Image.file(File(m.logo!), fit: BoxFit.cover)
                                : const Icon(Icons.school_outlined, size: 30),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Wrap(
                              spacing: 8,
                              children: [
                                FilledButton.tonalIcon(
                                  onPressed: () async {
                                    final p = await pickImage();
                                    if (p != null) {
                                      app.meta.logo = p;
                                      app.changed();
                                    }
                                  },
                                  icon: const Icon(Icons.add_photo_alternate_outlined),
                                  label: const Text('الشعار'),
                                ),
                                if (hasLogo)
                                  IconButton(
                                    onPressed: () {
                                      app.meta.logo = null;
                                      app.changed();
                                    },
                                    icon: const Icon(Icons.delete_outline),
                                  ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      f('authority', 'الإدارة / المديرية', m.authority, (v) => m.authority = v),
                      f('school', 'اسم المدرسة', m.school, (v) => m.school = v),
                      f('schoolType', 'نوع المدرسة (الابتدائية للبنين...)', m.schoolType,
                          (v) => m.schoolType = v),
                      f('bismillah', 'البسملة (اتركها فارغة لإخفائها)', m.bismillah,
                          (v) => m.bismillah = v),
                      f('title', 'عنوان الامتحان', m.title, (v) => m.title = v),
                      f('subtitle', 'سطر العام الدراسي / الدور', m.subtitle, (v) => m.subtitle = v),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: _MetaField(
                          key: ValueKey('subject-${m.subjectKey}'),
                          label: 'المادة (اضغط السهم للاختيار)',
                          initial: m.subject,
                          suffix: IconButton(
                            icon: const Icon(Icons.arrow_drop_down_circle_outlined),
                            onPressed: () => pickSubject(context),
                          ),
                          onChanged: (v) {
                            app.meta.subject = v;
                            app.changed();
                          },
                        ),
                      ),
                      Row(
                        children: [
                          Expanded(child: f('grade', 'الصف', m.grade, (v) => m.grade = v)),
                          const SizedBox(width: 10),
                          Expanded(child: f('duration', 'الزمن', m.duration, (v) => m.duration = v)),
                        ],
                      ),
                      Row(
                        children: [
                          Expanded(child: f('date', 'التاريخ', m.date, (v) => m.date = v)),
                          const SizedBox(width: 10),
                          Expanded(
                              child: f('total', 'الدرجة', m.total, (v) => m.total = v,
                                  kb: TextInputType.number)),
                        ],
                      ),
                      f('wish', 'عبارة ختامية', m.wish, (v) => m.wish = v),
                      f('teacher', 'اسم مدرس المادة (في الصفحة الأخيرة)', m.teacher,
                          (v) => m.teacher = v),
                    ],
                  ),
                ),
              ),
              Card(
                child: Column(
                  children: [
                    ListTile(
                      leading: const Icon(Icons.format_paint_outlined),
                      title: const Text('تنسيق الخط واللون'),
                      subtitle: const Text('الحجم • اللون • غامق • تحته خط'),
                      trailing: const Icon(Icons.chevron_left),
                      onTap: () => openFormatSheet(context),
                    ),
                    const Divider(height: 1),
                    ListTile(
                      leading: const Icon(Icons.border_outer),
                      title: const Text('إطار الورقة والعلامة المائية'),
                      trailing: const Icon(Icons.chevron_left),
                      onTap: () => openDesignSheet(context),
                    ),
                    const Divider(height: 1),
                    PopupMenuButton<String>(
                      onSelected: (v) {
                        app.numbering = v;
                        app.changed();
                      },
                      itemBuilder: (c) => [
                        for (final e in kNumberStyles.entries)
                          PopupMenuItem(value: e.key, child: Text('الترقيم: ${e.value}')),
                      ],
                      child: ListTile(
                        leading: const Icon(Icons.format_list_numbered),
                        title: const Text('الترقيم التلقائي'),
                        subtitle: Text(kNumberStyles[app.numbering] ?? ''),
                        trailing: const Icon(Icons.arrow_drop_down),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(4, 6, 4, 6),
                child: Text(
                  app.questions.isEmpty
                      ? 'لا توجد أسئلة بعد — اضغط «إضافة سؤال» أو أيقونة الكاميرا للاستيراد من صورة'
                      : 'اضغط مطولًا على أي سؤال ثم اسحبه لتغيير ترتيبه',
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            ],
          ),
        );

        return CustomScrollView(
          slivers: [
            SliverToBoxAdapter(child: header),
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              sliver: SliverReorderableList(
                itemCount: app.questions.length,
                onReorder: (o, n) {
                  app.checkpoint();
                  var nw = n;
                  if (nw > o) nw -= 1;
                  final x = app.questions.removeAt(o);
                  app.questions.insert(nw, x);
                  app.changed();
                },
                itemBuilder: (c, i) => ReorderableDelayedDragStartListener(
                  key: ValueKey(app.questions[i].id),
                  index: i,
                  child: _QuestionCard(index: i),
                ),
              ),
            ),
            const SliverToBoxAdapter(child: SizedBox(height: 130)),
          ],
        );
      },
    );
  }
}

class _QuestionCard extends StatelessWidget {
  final int index;
  const _QuestionCard({required this.index});

  @override
  Widget build(BuildContext context) {
    final q = app.questions[index];
    final t = typeOf(q.type);
    final n = app.numberOf(index);
    final label = n < 0 ? '' : '${numLabel(app.numbering, n)} ';
    final title = q.prompt.isNotEmpty ? q.prompt : t.label;
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 350),
      builder: (c, v, child) => Opacity(
        opacity: v,
        child: Transform.translate(offset: Offset(0, (1 - v) * 14), child: child),
      ),
      child: Card(
        child: ListTile(
          onTap: () => editQuestionFlow(context, index),
          leading: CircleAvatar(child: Icon(t.icon, size: 20)),
          title: Text('$label$title', maxLines: 2, overflow: TextOverflow.ellipsis),
          subtitle: Text(
              '${t.label}${q.marks > 0 ? ' • ${q.marks} درجات' : ''}${q.answer.isNotEmpty ? ' • له إجابة' : ''}'),
          trailing: PopupMenuButton<String>(
            onSelected: (v) {
              final l = app.questions;
              if (v == 'edit') {
                editQuestionFlow(context, index);
                return;
              }
              app.checkpoint();
              if (v == 'up' && index > 0) {
                final x = l.removeAt(index);
                l.insert(index - 1, x);
              } else if (v == 'down' && index < l.length - 1) {
                final x = l.removeAt(index);
                l.insert(index + 1, x);
              } else if (v == 'dup') {
                l.insert(index + 1, l[index].clone());
              } else if (v == 'del') {
                l.removeAt(index);
              }
              app.changed();
            },
            itemBuilder: (c) => const [
              PopupMenuItem(value: 'edit', child: Text('تعديل')),
              PopupMenuItem(value: 'up', child: Text('نقل للأعلى')),
              PopupMenuItem(value: 'down', child: Text('نقل للأسفل')),
              PopupMenuItem(value: 'dup', child: Text('تكرار')),
              PopupMenuItem(value: 'del', child: Text('حذف')),
            ],
          ),
        ),
      ),
    );
  }
}

// ───────────────────────── محرر السؤال ─────────────────────────

class RowsEditor extends StatefulWidget {
  final TextEditingController store;
  final List<String> cols;
  const RowsEditor({super.key, required this.store, required this.cols});
  @override
  State<RowsEditor> createState() => _RowsEditorState();
}

class _RowsEditorState extends State<RowsEditor> {
  late List<List<TextEditingController>> rows;

  List<TextEditingController> _blank() =>
      List.generate(widget.cols.length, (_) => TextEditingController());

  @override
  void initState() {
    super.initState();
    rows = widget.store.text
        .split('\n')
        .where((l) => l.trim().isNotEmpty)
        .map((l) => parseRow(l, widget.cols.length)
            .map((e) => TextEditingController(text: e))
            .toList())
        .toList();
    if (rows.isEmpty) rows.add(_blank());
  }

  @override
  void dispose() {
    for (final r in rows) {
      for (final c in r) {
        c.dispose();
      }
    }
    super.dispose();
  }

  void _sync() {
    widget.store.text = rows
        .where((r) => r.any((c) => c.text.trim().isNotEmpty))
        .map((r) => r.map((c) => c.text.replaceAll('\n', ' ').trim()).join(' || '))
        .join('\n');
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (var i = 0; i < rows.length; i++)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                children: [
                  Row(
                    children: [
                      Text('البند ${i + 1}', style: const TextStyle(fontWeight: FontWeight.bold)),
                      const Spacer(),
                      IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () {
                          setState(() {
                            final r = rows.removeAt(i);
                            for (final c in r) {
                              c.dispose();
                            }
                            if (rows.isEmpty) rows.add(_blank());
                          });
                          _sync();
                        },
                      ),
                    ],
                  ),
                  for (var k = 0; k < widget.cols.length; k++)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: TextField(
                        controller: rows[i][k],
                        onChanged: (_) => _sync(),
                        minLines: 1,
                        maxLines: k == 0 ? 4 : 2,
                        decoration: InputDecoration(
                          labelText: widget.cols[k],
                          border: const OutlineInputBorder(),
                          isDense: true,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        OutlinedButton.icon(
          onPressed: () => setState(() => rows.add(_blank())),
          icon: const Icon(Icons.add),
          label: const Text('إضافة بند'),
        ),
      ],
    );
  }
}

class QuestionEditor extends StatefulWidget {
  final Question question;
  const QuestionEditor({super.key, required this.question});
  @override
  State<QuestionEditor> createState() => _QuestionEditorState();
}

class _QuestionEditorState extends State<QuestionEditor> {
  late final TextEditingController prompt;
  late final TextEditingController marks;
  late final TextEditingController answer;
  final Map<String, TextEditingController> _c = {};
  late String type;
  String lang = 'ar';
  String? imagePath;

  TextEditingController c(String k) =>
      _c.putIfAbsent(k, () => TextEditingController(text: widget.question.data[k] ?? ''));

  @override
  void initState() {
    super.initState();
    final q = widget.question;
    type = q.type;
    prompt = TextEditingController(text: q.prompt);
    marks = TextEditingController(text: '${q.marks}');
    answer = TextEditingController(text: q.answer);
    lang = q.lang;
    imagePath = q.data['imagePath'];
  }

  @override
  void dispose() {
    prompt.dispose();
    marks.dispose();
    answer.dispose();
    for (final x in _c.values) {
      x.dispose();
    }
    super.dispose();
  }

  Question _collect() {
    final q = widget.question;
    final data = <String, String>{};
    for (final f in kFields[type] ?? const <FieldDef>[]) {
      data[f.key] = c(f.key).text;
    }
    if (kRows.containsKey(type)) data['items'] = c('items').text;
    if (type == 'image' && imagePath != null) data['imagePath'] = imagePath!;
    return Question(
      id: q.id,
      type: type,
      prompt: prompt.text.trim(),
      marks: int.tryParse(marks.text) ?? 0,
      lang: lang,
      answer: answer.text.trim(),
      data: data,
    );
  }

  void _save() {
    final q = _collect();
    final empty = q.prompt.isEmpty &&
        q.data.entries
            .where((e) => e.key != 'imagePath')
            .every((e) => e.value.trim().isEmpty) &&
        imagePath == null;
    if (empty) {
      snack(context, 'اكتب نص السؤال أو بياناته أولاً');
      return;
    }
    Navigator.pop(context, q);
  }

  Future<void> _ocr() async {
    final src = await chooseSource(context);
    if (src == null) return;
    final p = await pickImageSrc(src, persist: false);
    if (p == null || !mounted) return;
    final t = await withProgress<String>(context, 'جاري استخراج النص من الصورة...', () => aiOcr(p));
    if (t != null && mounted) {
      setState(() => prompt.text = prompt.text.isEmpty ? t : '${prompt.text}\n$t');
    }
  }

  Future<void> _aiAnswer() async {
    final q = _collect();
    final r = await withProgress<String>(context, 'جاري توليد الإجابة...', () => aiAnswerOne(q));
    if (r != null && mounted) setState(() => answer.text = r);
  }

  Future<void> _pickImg() async {
    final src = await chooseSource(context);
    if (src == null) return;
    final p = await pickImageSrc(src);
    if (p == null || !mounted) return;
    await _cropImg(p);
  }

  Future<void> _cropImg(String p) async {
    final cropped = await Navigator.of(context)
        .push<String>(fancyRoute<String>(CropPage(path: p)));
    if (!mounted) return;
    setState(() => imagePath = cropped ?? p);
  }

  @override
  Widget build(BuildContext context) {
    final t = typeOf(type);
    final allowed = typesFor(app.meta.subjectKey).map((e) => e.key).toList();
    if (!allowed.contains(type)) allowed.add(type);
    return Scaffold(
      appBar: AppBar(
        title: Text(t.label),
        actions: [IconButton(icon: const Icon(Icons.check), onPressed: _save)],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SizedBox(
            height: 44,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                for (final k in allowed)
                  Padding(
                    padding: const EdgeInsetsDirectional.only(end: 8),
                    child: ChoiceChip(
                      label: Text(typeOf(k).label),
                      selected: type == k,
                      onSelected: (_) {
                        tapFeedback();
                        setState(() => type = k);
                      },
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: prompt,
            minLines: 2,
            maxLines: 8,
            decoration: InputDecoration(
              labelText: type == 'section' ? 'عنوان القسم' : 'نص السؤال أو عنوان الفرع',
              border: const OutlineInputBorder(),
              suffixIcon: IconButton(
                tooltip: 'استخراج نص من صورة (ذكاء اصطناعي)',
                icon: const Icon(Icons.document_scanner_outlined),
                onPressed: _ocr,
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (kRows.containsKey(type))
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: RowsEditor(
                key: ValueKey('rows-$type'),
                store: c('items'),
                cols: kRows[type]!,
              ),
            ),
          for (final f in kFields[type] ?? const <FieldDef>[])
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: TextField(
                controller: c(f.key),
                minLines: f.multiline ? 3 : 1,
                maxLines: f.multiline ? 8 : 1,
                decoration: InputDecoration(
                  labelText: f.label,
                  hintText: f.hint.isEmpty ? null : f.hint,
                  border: const OutlineInputBorder(),
                ),
              ),
            ),
          if (type == 'image')
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(
                children: [
                  FilledButton.tonalIcon(
                    onPressed: _pickImg,
                    icon: const Icon(Icons.add_a_photo_outlined),
                    label: const Text('كاميرا / معرض'),
                  ),
                  const SizedBox(width: 8),
                  if (imagePath != null && File(imagePath!).existsSync()) ...[
                    IconButton(
                      tooltip: 'قص',
                      icon: const Icon(Icons.crop),
                      onPressed: () => _cropImg(imagePath!),
                    ),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.file(File(imagePath!), width: 56, height: 56, fit: BoxFit.cover),
                    ),
                  ],
                ],
              ),
            ),
          if (type != 'section')
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: marks,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'الدرجة',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'ar', label: Text('عربي')),
                    ButtonSegment(value: 'en', label: Text('EN')),
                  ],
                  selected: {lang},
                  onSelectionChanged: (s) => setState(() => lang = s.first),
                ),
              ],
            ),
          if (type != 'section') ...[
            const SizedBox(height: 12),
            TextField(
              controller: answer,
              minLines: 2,
              maxLines: 8,
              decoration: InputDecoration(
                labelText: 'الإجابة النموذجية (تظهر في نسخة المدرس)',
                border: const OutlineInputBorder(),
                suffixIcon: IconButton(
                  tooltip: 'توليد بالذكاء الاصطناعي',
                  icon: const Icon(Icons.auto_awesome),
                  onPressed: _aiAnswer,
                ),
              ),
            ),
          ],
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.check),
            label: const Text('حفظ السؤال'),
          ),
        ],
      ),
    );
  }
}

// ───────────────────────── المحفوظات ─────────────────────────

class LibraryTab extends StatefulWidget {
  final VoidCallback onOpened;
  const LibraryTab({super.key, required this.onOpened});
  @override
  State<LibraryTab> createState() => _LibraryTabState();
}

class _LibraryTabState extends State<LibraryTab> {
  late Future<List<SavedExam>> _f = listSaved();

  void _reload() => setState(() => _f = listSaved());

  Future<void> _saveNow() async {
    final name = await askText(context, 'اسم الملف', app.meta.subject);
    if (name == null) return;
    final p = await saveCurrentAs(name);
    if (mounted) snack(context, 'تم الحفظ: $p');
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: _saveNow,
                  icon: const Icon(Icons.save),
                  label: const Text('حفظ الامتحان الحالي'),
                ),
              ),
              IconButton(onPressed: _reload, icon: const Icon(Icons.refresh)),
            ],
          ),
        ),
        Expanded(
          child: FutureBuilder<List<SavedExam>>(
            future: _f,
            builder: (c, snap) {
              if (snap.connectionState != ConnectionState.done) {
                return const Center(child: CircularProgressIndicator());
              }
              final list = snap.data ?? [];
              if (list.isEmpty) {
                return const Center(child: Text('لا توجد امتحانات محفوظة بعد'));
              }
              return ListView.builder(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 24),
                itemCount: list.length,
                itemBuilder: (c, i) {
                  final s = list[i];
                  final d = s.modified;
                  return Card(
                    child: ListTile(
                      leading: const CircleAvatar(child: Icon(Icons.description_outlined)),
                      title: Text(s.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text(
                          '${s.subject} • ${s.count} سؤال • ${d.year}/${d.month}/${d.day}'),
                      onTap: () async {
                        await loadSaved(s);
                        if (context.mounted) {
                          snack(context, 'تم فتح الامتحان');
                          widget.onOpened();
                        }
                      },
                      trailing: PopupMenuButton<String>(
                        onSelected: (v) async {
                          if (v == 'open') {
                            await loadSaved(s);
                            if (context.mounted) widget.onOpened();
                          } else if (v == 'share') {
                            await shareSaved(s);
                          } else if (v == 'del') {
                            final ok = await showDialog<bool>(
                              context: context,
                              builder: (ctx) => AlertDialog(
                                title: const Text('حذف الامتحان'),
                                content: Text('سيتم حذف «${s.name}» نهائيًا.'),
                                actions: [
                                  TextButton(
                                      onPressed: () => Navigator.pop(ctx, false),
                                      child: const Text('إلغاء')),
                                  FilledButton(
                                      onPressed: () => Navigator.pop(ctx, true),
                                      child: const Text('حذف')),
                                ],
                              ),
                            );
                            if (ok == true) {
                              await deleteSaved(s);
                              _reload();
                            }
                          }
                        },
                        itemBuilder: (c) => const [
                          PopupMenuItem(value: 'open', child: Text('فتح وتعديل')),
                          PopupMenuItem(value: 'share', child: Text('مشاركة')),
                          PopupMenuItem(value: 'del', child: Text('حذف')),
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

// ───────────────────────── الإعدادات ─────────────────────────

class _PlainField extends StatefulWidget {
  final String label, initial;
  final bool obscure;
  final ValueChanged<String> onChanged;
  const _PlainField({
    super.key,
    required this.label,
    required this.initial,
    required this.onChanged,
    this.obscure = false,
  });
  @override
  State<_PlainField> createState() => _PlainFieldState();
}

class _PlainFieldState extends State<_PlainField> {
  late final TextEditingController c = TextEditingController(text: widget.initial);
  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => TextField(
        controller: c,
        obscureText: widget.obscure,
        onChanged: widget.onChanged,
        decoration: InputDecoration(
          labelText: widget.label,
          border: const OutlineInputBorder(),
          isDense: true,
        ),
      );
}

class SettingsTab extends StatelessWidget {
  const SettingsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        return ListView(
          padding: const EdgeInsets.all(14),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('المظهر', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 12),
                    SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(value: 'light', icon: Icon(Icons.light_mode), label: Text('فاتح')),
                        ButtonSegment(value: 'dark', icon: Icon(Icons.dark_mode), label: Text('داكن')),
                        ButtonSegment(value: 'eye', icon: Icon(Icons.visibility), label: Text('راحة العين')),
                      ],
                      selected: {app.themeMode},
                      onSelectionChanged: (s) {
                        app.themeMode = s.first;
                        app.changed();
                      },
                    ),
                    const SizedBox(height: 16),
                    const Text('لون التطبيق'),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      children: [
                        for (final c in kSeeds)
                          GestureDetector(
                            onTap: () {
                              app.seed = c;
                              app.changed();
                            },
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 200),
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: Color(c),
                                shape: BoxShape.circle,
                                border: Border.all(
                                  width: app.seed == c ? 3 : 1,
                                  color: app.seed == c ? Colors.amber : Colors.black26,
                                ),
                              ),
                              child: app.seed == c
                                  ? const Icon(Icons.check, color: Colors.white, size: 20)
                                  : null,
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Card(
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.folder_open),
                    title: const Text('مجلد حفظ الأسئلة والملفات'),
                    subtitle: Text(app.saveDir ?? 'المجلد الافتراضي للتطبيق'),
                    trailing: app.saveDir == null
                        ? const Icon(Icons.chevron_left)
                        : IconButton(
                            icon: const Icon(Icons.restart_alt),
                            onPressed: () {
                              app.saveDir = null;
                              app.changed();
                            },
                          ),
                    onTap: () => chooseFolder(),
                  ),
                  SwitchListTile(
                    title: const Text('إظهار الدرجات بجانب الأسئلة'),
                    value: app.showMarks,
                    onChanged: (v) {
                      app.showMarks = v;
                      app.changed();
                    },
                  ),
                  SwitchListTile(
                    title: const Text('ترقيم الصفحات'),
                    value: app.pageNumbers,
                    onChanged: (v) {
                      app.pageNumbers = v;
                      app.changed();
                    },
                  ),
                  SwitchListTile(
                    title: const Text('اهتزاز خفيف عند اللمس'),
                    value: app.haptic,
                    onChanged: (v) {
                      app.haptic = v;
                      app.changed();
                    },
                  ),
                ],
              ),
            ),
            const _AiCard(),
            Card(
              child: Column(
                children: [
                  SwitchListTile(
                    secondary: const Icon(Icons.system_update_alt),
                    title: const Text('التحقق من التحديثات عند فتح التطبيق'),
                    value: app.autoUpdate,
                    onChanged: (v) {
                      app.autoUpdate = v;
                      app.changed();
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.share),
                    title: const Text('مشاركة التطبيق'),
                    onTap: () {
                      tapFeedback();
                      shareApp();
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.info_outline),
                    title: const Text('حول التطبيق'),
                    subtitle: const Text('من نحن • ما الجديد • التحقق من التحديث'),
                    trailing: const Icon(Icons.chevron_left),
                    onTap: () => Navigator.of(context).push(fancyRoute<void>(const AboutPage())),
                  ),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.all(12),
              child: Text(
                'عند اختيار مجلد خارجي يطلب أندرويد إذن «الوصول إلى كل الملفات». '
                'إذا رُفض الإذن تُحفظ الملفات في مجلد التطبيق.',
                style: TextStyle(fontSize: 12),
              ),
            ),
          ],
        );
      },
    );
  }
}


class _AiCard extends StatefulWidget {
  const _AiCard();
  @override
  State<_AiCard> createState() => _AiCardState();
}

class _AiCardState extends State<_AiCard> {
  int _epoch = 0;

  Future<void> _fetchModels() async {
    final list = await withProgress<List<String>>(context, 'جاري جلب النماذج...', listModels);
    if (list == null || !mounted) return;
    if (list.isEmpty) {
      snack(context, 'لم يُرجع المزود أي نموذج');
      return;
    }
    final picked = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (c) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(c).size.height * 0.7),
          child: ListView(
            shrinkWrap: true,
            children: [
              for (final m in list)
                ListTile(
                  dense: true,
                  title: Text(m),
                  trailing: m == app.aiModel ? const Icon(Icons.check) : null,
                  onTap: () => Navigator.pop(c, m),
                ),
            ],
          ),
        ),
      ),
    );
    if (picked != null) {
      app.aiModels[app.aiProvider] = picked;
      app.changed();
      setState(() => _epoch++);
    }
  }

  Future<void> _test() async {
    final r = await withProgress<String>(
        context, 'جاري اختبار الاتصال...', () => callAI([const AiPart.text('Reply with the single word: OK')], maxTokens: 50));
    if (r != null && mounted) {
      snack(context, r.trim().isEmpty ? 'اتصل المزود لكن الرد فارغ' : 'نجح الاتصال ✓');
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final p = app.aiProvider;
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('الذكاء الاصطناعي', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 6),
                const Text(
                  'اختر المزود الذي تملك مفتاحه. يُستخدم لاستخراج النص من الصور واستيراد الأسئلة '
                  'وتوليد الإجابات (ميزات الصور تحتاج نموذجًا يدعم الرؤية). الاستخدام يُحاسَب على '
                  'حسابك لدى المزود، والمفتاح يُحفظ على جهازك فقط.',
                  style: TextStyle(fontSize: 12),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    for (final e in kProviderNames.entries)
                      ChoiceChip(
                        label: Text(e.value),
                        selected: p == e.key,
                        onSelected: (_) {
                          app.aiProvider = e.key;
                          app.changed();
                        },
                      ),
                  ],
                ),
                const SizedBox(height: 12),
                if (p == 'custom') ...[
                  Row(
                    children: [
                      Expanded(
                        child: _PlainField(
                          key: ValueKey('url-$p-$_epoch'),
                          label: 'رابط المزود (Base URL)',
                          initial: app.customUrl,
                          onChanged: (v) {
                            app.customUrl = v;
                            app.changed();
                          },
                        ),
                      ),
                      PopupMenuButton<List<String>>(
                        tooltip: 'إعدادات جاهزة',
                        icon: const Icon(Icons.list_alt),
                        onSelected: (v) {
                          app.customUrl = v[1];
                          app.aiModels['custom'] = v[2];
                          app.changed();
                          setState(() => _epoch++);
                        },
                        itemBuilder: (c) => [
                          for (final e in kCustomPresets)
                            PopupMenuItem(value: e, child: Text(e[0])),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                ],
                _PlainField(
                  key: ValueKey('key-$p'),
                  label: 'مفتاح API',
                  initial: app.apiKey,
                  obscure: true,
                  onChanged: (v) {
                    app.aiKeys[p] = v;
                    app.changed();
                  },
                ),
                const SizedBox(height: 10),
                _PlainField(
                  key: ValueKey('model-$p-$_epoch'),
                  label: 'اسم النموذج',
                  initial: app.aiModel,
                  onChanged: (v) {
                    app.aiModels[p] = v;
                    app.changed();
                  },
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  children: [
                    OutlinedButton.icon(
                      onPressed: _fetchModels,
                      icon: const Icon(Icons.cloud_download_outlined),
                      label: const Text('جلب النماذج المتاحة'),
                    ),
                    OutlinedButton.icon(
                      onPressed: _test,
                      icon: const Icon(Icons.bolt),
                      label: const Text('اختبار الاتصال'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
