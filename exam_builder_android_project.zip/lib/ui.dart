import 'dart:io';
import 'package:flutter/material.dart';
import 'models.dart';
import 'files.dart';

void snack(BuildContext c, String m) {
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));
}

Route<T> fancyRoute<T>(Widget page) => PageRouteBuilder<T>(
      transitionDuration: const Duration(milliseconds: 320),
      pageBuilder: (c, a, s) => page,
      transitionsBuilder: (c, a, s, child) => FadeTransition(
        opacity: a,
        child: SlideTransition(
          position: Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
              .chain(CurveTween(curve: Curves.easeOutCubic))
              .animate(a),
          child: child,
        ),
      ),
    );

// ───────────────────────── المحرر ─────────────────────────

Future<void> addQuestionFlow(BuildContext context) async {
  final type = await showModalBottomSheet<String>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (c) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('اختر نوع السؤال', style: Theme.of(c).textTheme.titleMedium),
            const SizedBox(height: 12),
            Flexible(
              child: GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.05,
                children: [
                  for (final t in kTypes)
                    _Tile(
                      label: t.label,
                      child: Icon(t.icon, size: 28),
                      onTap: () => Navigator.pop(c, t.key),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
  if (type == null || !context.mounted) return;
  final q = await Navigator.of(context).push<Question>(fancyRoute<Question>(
    QuestionEditor(
      question: Question(id: stamp(), type: type, marks: 5),
    ),
  ));
  if (q != null) {
    app.questions.add(q);
    app.changed();
  }
}

Future<void> editQuestionFlow(BuildContext context, int i) async {
  final q = await Navigator.of(context).push<Question>(
      fancyRoute<Question>(QuestionEditor(question: app.questions[i])));
  if (q != null) {
    app.questions[i] = q;
    app.changed();
  }
}

class _Tile extends StatelessWidget {
  final String label;
  final Widget child;
  final VoidCallback onTap;
  const _Tile({required this.label, required this.child, required this.onTap});
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      color: cs.secondaryContainer,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              child,
              const SizedBox(height: 6),
              Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}

Future<void> pickSubject(BuildContext context) async {
  final s = await showModalBottomSheet<SubjectDef>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (c) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('اختر المادة', style: Theme.of(c).textTheme.titleMedium),
            const SizedBox(height: 12),
            Flexible(
              child: GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.05,
                children: [
                  for (final sub in kSubjects)
                    _Tile(
                      label: sub.label,
                      child: Text(sub.icon, style: const TextStyle(fontSize: 26)),
                      onTap: () => Navigator.pop(c, sub),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
  if (s != null) {
    app.meta.subjectKey = s.key;
    app.meta.subject = s.label;
    app.changed();
  }
}

void openFormatSheet(BuildContext context) {
  int group = 0;
  showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (c) => StatefulBuilder(
      builder: (c, setS) => ListenableBuilder(
        listenable: app,
        builder: (c, _) {
          final f = group == 0 ? app.headerFmt : app.bodyFmt;
          final minS = group == 0 ? 14.0 : 10.0;
          final maxS = group == 0 ? 36.0 : 26.0;
          final size = f.size < minS ? minS : (f.size > maxS ? maxS : f.size);
          return SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SegmentedButton<int>(
                    segments: const [
                      ButtonSegment(value: 0, label: Text('العنوان واسم المدرسة')),
                      ButtonSegment(value: 1, label: Text('الأسئلة')),
                    ],
                    selected: {group},
                    onSelectionChanged: (s) => setS(() => group = s.first),
                  ),
                  const SizedBox(height: 14),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.black12),
                    ),
                    child: Text('نص تجريبي — Sample', style: f.prompt()),
                  ),
                  const SizedBox(height: 12),
                  Text('حجم الخط: ${size.round()}'),
                  Slider(
                    min: minS,
                    max: maxS,
                    divisions: (maxS - minS).round(),
                    value: size,
                    onChanged: (v) {
                      f.size = v;
                      app.changed();
                    },
                  ),
                  const Text('اللون'),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      for (final col in kPalette)
                        GestureDetector(
                          onTap: () {
                            f.color = col;
                            app.changed();
                          },
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            width: 36,
                            height: 36,
                            decoration: BoxDecoration(
                              color: Color(col),
                              shape: BoxShape.circle,
                              border: Border.all(
                                width: f.color == col ? 3 : 1,
                                color: f.color == col ? Colors.amber : Colors.black26,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Wrap(
                    spacing: 8,
                    children: [
                      FilterChip(
                        label: const Text('غامق'),
                        selected: f.bold,
                        onSelected: (v) {
                          f.bold = v;
                          app.changed();
                        },
                      ),
                      FilterChip(
                        label: const Text('تحته خط'),
                        selected: f.underline,
                        onSelected: (v) {
                          f.underline = v;
                          app.changed();
                        },
                      ),
                      FilterChip(
                        label: const Text('مائل'),
                        selected: f.italic,
                        onSelected: (v) {
                          f.italic = v;
                          app.changed();
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    ),
  );
}

class _MetaField extends StatefulWidget {
  final String label;
  final String initial;
  final ValueChanged<String> onChanged;
  final TextInputType? keyboard;
  final Widget? suffix;
  const _MetaField({
    super.key,
    required this.label,
    required this.initial,
    required this.onChanged,
    this.keyboard,
    this.suffix,
  });
  @override
  State<_MetaField> createState() => _MetaFieldState();
}

class _MetaFieldState extends State<_MetaField> {
  late final TextEditingController c = TextEditingController(text: widget.initial);
  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => TextField(
        controller: c,
        keyboardType: widget.keyboard,
        onChanged: widget.onChanged,
        decoration: InputDecoration(
          labelText: widget.label,
          suffixIcon: widget.suffix,
          border: const OutlineInputBorder(),
          isDense: true,
        ),
      );
}

class EditorTab extends StatelessWidget {
  const EditorTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final m = app.meta;
        final hasLogo = m.logo != null && File(m.logo!).existsSync();
        return ListView(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 100),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('بيانات الامتحان', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Container(
                          width: 64,
                          height: 64,
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.black26),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          clipBehavior: Clip.antiAlias,
                          child: hasLogo
                              ? Image.file(File(m.logo!), fit: BoxFit.cover)
                              : const Icon(Icons.school_outlined, size: 30),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Wrap(
                            spacing: 8,
                            children: [
                              FilledButton.tonalIcon(
                                onPressed: () async {
                                  final p = await pickImage();
                                  if (p != null) {
                                    app.meta.logo = p;
                                    app.changed();
                                  }
                                },
                                icon: const Icon(Icons.add_photo_alternate_outlined),
                                label: const Text('شعار المدرسة'),
                              ),
                              if (hasLogo)
                                IconButton(
                                  onPressed: () {
                                    app.meta.logo = null;
                                    app.changed();
                                  },
                                  icon: const Icon(Icons.delete_outline),
                                ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    _MetaField(
                      key: const ValueKey('school'),
                      label: 'اسم المدرسة',
                      initial: m.school,
                      onChanged: (v) {
                        app.meta.school = v;
                        app.changed();
                      },
                    ),
                    const SizedBox(height: 10),
                    _MetaField(
                      key: ValueKey('subject-${m.subjectKey}'),
                      label: 'المادة (اضغط السهم للاختيار)',
                      initial: m.subject,
                      suffix: IconButton(
                        icon: const Icon(Icons.arrow_drop_down_circle_outlined),
                        onPressed: () => pickSubject(context),
                      ),
                      onChanged: (v) {
                        app.meta.subject = v;
                        app.changed();
                      },
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: _MetaField(
                            key: const ValueKey('grade'),
                            label: 'الصف',
                            initial: m.grade,
                            onChanged: (v) {
                              app.meta.grade = v;
                              app.changed();
                            },
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _MetaField(
                            key: const ValueKey('duration'),
                            label: 'الزمن',
                            initial: m.duration,
                            onChanged: (v) {
                              app.meta.duration = v;
                              app.changed();
                            },
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _MetaField(
                            key: const ValueKey('total'),
                            label: 'الدرجة',
                            initial: m.total,
                            keyboard: TextInputType.number,
                            onChanged: (v) {
                              app.meta.total = v;
                              app.changed();
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Card(
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.format_paint_outlined),
                    title: const Text('تنسيق الخط واللون'),
                    subtitle: const Text('الحجم • اللون • غامق • تحته خط'),
                    trailing: const Icon(Icons.chevron_left),
                    onTap: () => openFormatSheet(context),
                  ),
                  const Divider(height: 1),
                  PopupMenuButton<String>(
                    onSelected: (v) {
                      app.numbering = v;
                      app.changed();
                    },
                    itemBuilder: (c) => [
                      for (final e in kNumberStyles.entries)
                        PopupMenuItem(value: e.key, child: Text('الترقيم: ${e.value}')),
                    ],
                    child: ListTile(
                      leading: const Icon(Icons.format_list_numbered),
                      title: const Text('الترقيم التلقائي'),
                      subtitle: Text(kNumberStyles[app.numbering] ?? ''),
                      trailing: const Icon(Icons.arrow_drop_down),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            if (app.questions.isEmpty)
              const Padding(
                padding: EdgeInsets.all(32),
                child: Center(child: Text('لا توجد أسئلة بعد — اضغط «إضافة سؤال»')),
              ),
            for (var i = 0; i < app.questions.length; i++)
              _QuestionCard(key: ValueKey(app.questions[i].id), index: i),
          ],
        );
      },
    );
  }
}

class _QuestionCard extends StatelessWidget {
  final int index;
  const _QuestionCard({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    final q = app.questions[index];
    final t = typeOf(q.type);
    final title = q.prompt.isNotEmpty ? q.prompt : t.label;
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 350),
      builder: (c, v, child) => Opacity(
        opacity: v,
        child: Transform.translate(offset: Offset(0, (1 - v) * 14), child: child),
      ),
      child: Card(
        child: ListTile(
          onTap: () => editQuestionFlow(context, index),
          leading: CircleAvatar(child: Icon(t.icon, size: 20)),
          title: Text('${numLabel(app.numbering, index)} $title',
              maxLines: 2, overflow: TextOverflow.ellipsis),
          subtitle: Text('${t.label} • ${q.marks} درجات'),
          trailing: PopupMenuButton<String>(
            onSelected: (v) {
              final l = app.questions;
              if (v == 'edit') {
                editQuestionFlow(context, index);
              } else if (v == 'up' && index > 0) {
                final x = l.removeAt(index);
                l.insert(index - 1, x);
                app.changed();
              } else if (v == 'down' && index < l.length - 1) {
                final x = l.removeAt(index);
                l.insert(index + 1, x);
                app.changed();
              } else if (v == 'dup') {
                l.insert(index + 1, l[index].clone());
                app.changed();
              } else if (v == 'del') {
                l.removeAt(index);
                app.changed();
              }
            },
            itemBuilder: (c) => const [
              PopupMenuItem(value: 'edit', child: Text('تعديل')),
              PopupMenuItem(value: 'up', child: Text('نقل للأعلى')),
              PopupMenuItem(value: 'down', child: Text('نقل للأسفل')),
              PopupMenuItem(value: 'dup', child: Text('تكرار')),
              PopupMenuItem(value: 'del', child: Text('حذف')),
            ],
          ),
        ),
      ),
    );
  }
}

// ───────────────────────── محرر السؤال ─────────────────────────

class QuestionEditor extends StatefulWidget {
  final Question question;
  const QuestionEditor({super.key, required this.question});
  @override
  State<QuestionEditor> createState() => _QuestionEditorState();
}

class _QuestionEditorState extends State<QuestionEditor> {
  late final TextEditingController prompt;
  late final TextEditingController marks;
  final Map<String, TextEditingController> fc = {};
  String lang = 'ar';
  String? imagePath;

  @override
  void initState() {
    super.initState();
    final q = widget.question;
    prompt = TextEditingController(text: q.prompt);
    marks = TextEditingController(text: '${q.marks}');
    lang = q.lang;
    imagePath = q.data['imagePath'];
    for (final f in kFields[q.type] ?? const <FieldDef>[]) {
      fc[f.key] = TextEditingController(text: q.data[f.key] ?? '');
    }
  }

  @override
  void dispose() {
    prompt.dispose();
    marks.dispose();
    for (final c in fc.values) {
      c.dispose();
    }
    super.dispose();
  }

  void _save() {
    final q = widget.question;
    final data = <String, String>{};
    fc.forEach((k, v) => data[k] = v.text);
    if (imagePath != null) data['imagePath'] = imagePath!;
    final empty =
        prompt.text.trim().isEmpty && data.values.every((v) => v.trim().isEmpty);
    if (empty) {
      snack(context, 'اكتب نص السؤال أو بياناته أولاً');
      return;
    }
    Navigator.pop(
      context,
      Question(
        id: q.id,
        type: q.type,
        prompt: prompt.text.trim(),
        marks: int.tryParse(marks.text) ?? 0,
        lang: lang,
        data: data,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.question;
    final t = typeOf(q.type);
    return Scaffold(
      appBar: AppBar(
        title: Text(t.label),
        actions: [IconButton(icon: const Icon(Icons.check), onPressed: _save)],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: prompt,
            minLines: 2,
            maxLines: 6,
            decoration: const InputDecoration(
              labelText: 'نص السؤال أو عنوان الفرع',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          for (final f in kFields[q.type] ?? const <FieldDef>[])
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: TextField(
                controller: fc[f.key],
                minLines: f.multiline ? 3 : 1,
                maxLines: f.multiline ? 8 : 1,
                decoration: InputDecoration(
                  labelText: f.label,
                  hintText: f.hint.isEmpty ? null : f.hint,
                  border: const OutlineInputBorder(),
                ),
              ),
            ),
          if (q.type == 'image')
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(
                children: [
                  FilledButton.tonalIcon(
                    onPressed: () async {
                      final p = await pickImage();
                      if (p != null) setState(() => imagePath = p);
                    },
                    icon: const Icon(Icons.image_outlined),
                    label: const Text('اختيار صورة من المعرض'),
                  ),
                  const SizedBox(width: 12),
                  if (imagePath != null && File(imagePath!).existsSync())
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.file(File(imagePath!), width: 56, height: 56, fit: BoxFit.cover),
                    ),
                ],
              ),
            ),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: marks,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'الدرجة',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'ar', label: Text('عربي')),
                  ButtonSegment(value: 'en', label: Text('EN')),
                ],
                selected: {lang},
                onSelectionChanged: (s) => setState(() => lang = s.first),
              ),
            ],
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.check),
            label: const Text('حفظ السؤال'),
          ),
        ],
      ),
    );
  }
}

// ───────────────────────── الإعدادات ─────────────────────────

class SettingsTab extends StatelessWidget {
  const SettingsTab({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        return ListView(
          padding: const EdgeInsets.all(14),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('المظهر', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 12),
                    SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(value: 'light', icon: Icon(Icons.light_mode), label: Text('فاتح')),
                        ButtonSegment(value: 'dark', icon: Icon(Icons.dark_mode), label: Text('داكن')),
                        ButtonSegment(value: 'eye', icon: Icon(Icons.visibility), label: Text('راحة العين')),
                      ],
                      selected: {app.themeMode},
                      onSelectionChanged: (s) {
                        app.themeMode = s.first;
                        app.changed();
                      },
                    ),
                    const SizedBox(height: 16),
                    const Text('لون التطبيق'),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      children: [
                        for (final c in kSeeds)
                          GestureDetector(
                            onTap: () {
                              app.seed = c;
                              app.changed();
                            },
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 200),
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: Color(c),
                                shape: BoxShape.circle,
                                border: Border.all(
                                  width: app.seed == c ? 3 : 1,
                                  color: app.seed == c ? Colors.amber : Colors.black26,
                                ),
                              ),
                              child: app.seed == c
                                  ? const Icon(Icons.check, color: Colors.white, size: 20)
                                  : null,
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.folder_open),
                title: const Text('مجلد حفظ الأسئلة والملفات'),
                subtitle: Text(app.saveDir ?? 'المجلد الافتراضي للتطبيق'),
                trailing: app.saveDir == null
                    ? const Icon(Icons.chevron_left)
                    : IconButton(
                        icon: const Icon(Icons.restart_alt),
                        onPressed: () {
                          app.saveDir = null;
                          app.changed();
                        },
                      ),
                onTap: () => chooseFolder(),
              ),
            ),
            const Padding(
              padding: EdgeInsets.all(12),
              child: Text(
                'عند اختيار مجلد خارجي يطلب أندرويد إذن «الوصول إلى كل الملفات». '
                'إذا رُفض الإذن تُحفظ الملفات في مجلد التطبيق.',
                style: TextStyle(fontSize: 12),
              ),
            ),
          ],
        );
      },
    );
  }
}
