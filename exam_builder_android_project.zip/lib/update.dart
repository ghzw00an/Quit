import 'dart:io';
import 'dart:convert';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';

/// مستودع GitHub الذي تُنشر فيه النسخ (يجب أن يكون عامًا).
const String kRepo = 'ghzw00an/Quit';
const String kAppVersion = '2.3';
const int kBuild = int.fromEnvironment('BUILD_NUMBER', defaultValue: 1);
const String kReleasesUrl = 'https://github.com/$kRepo/releases/latest';

class UpdateInfo {
  final int build;
  final String tag, notes, url;
  UpdateInfo(this.build, this.tag, this.notes, this.url);
  bool get isNewer => build > kBuild;
}

Future<UpdateInfo> fetchLatest() async {
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 15);
  try {
    final req = await client
        .getUrl(Uri.parse('https://api.github.com/repos/$kRepo/releases/latest'));
    req.headers.set('accept', 'application/vnd.github+json');
    req.headers.set('user-agent', 'exam-builder-app');
    final res = await req.close().timeout(const Duration(seconds: 30));
    final body = await res.transform(utf8.decoder).join();
    if (res.statusCode == 404) {
      throw 'لا توجد إصدارات منشورة بعد (تأكد أن المستودع عام)';
    }
    if (res.statusCode != 200) throw 'تعذر الاتصال بـ GitHub (${res.statusCode})';
    final j = jsonDecode(body) as Map<String, dynamic>;
    final tag = j['tag_name']?.toString() ?? '';
    final m = RegExp(r'(\d+)$').firstMatch(tag);
    if (m == null) throw 'رقم الإصدار غير مفهوم: $tag';
    String url = '';
    for (final a in (j['assets'] as List? ?? [])) {
      final u = a['browser_download_url']?.toString() ?? '';
      if (u.endsWith('.apk')) {
        url = u;
        break;
      }
    }
    if (url.isEmpty) throw 'لا يوجد ملف APK في هذا الإصدار';
    return UpdateInfo(int.parse(m.group(1)!), tag, j['body']?.toString() ?? '', url);
  } finally {
    client.close();
  }
}

/// ينزّل الـ APK ثم يفتح مثبّت أندرويد.
Future<void> downloadAndInstall(UpdateInfo u, void Function(double) onProgress) async {
  final dir = await getTemporaryDirectory();
  final f = File('${dir.path}/update_${u.build}.apk');
  if (await f.exists()) await f.delete();
  final client = HttpClient()..connectionTimeout = const Duration(seconds: 20);
  try {
    final req = await client.getUrl(Uri.parse(u.url));
    req.headers.set('user-agent', 'exam-builder-app');
    req.followRedirects = true;
    req.maxRedirects = 8;
    final res = await req.close();
    if (res.statusCode != 200) throw 'فشل التنزيل (${res.statusCode})';
    final total = res.contentLength;
    var got = 0;
    final sink = f.openWrite();
    try {
      await for (final chunk in res) {
        sink.add(chunk);
        got += chunk.length;
        if (total > 0) onProgress(got / total);
      }
    } finally {
      await sink.close();
    }
  } finally {
    client.close();
  }
  if (await f.length() < 1000000) throw 'الملف المنزَّل غير مكتمل';
  final r = await OpenFilex.open(f.path, type: 'application/vnd.android.package-archive');
  if (r.type != ResultType.done) {
    throw 'تعذر فتح المثبّت: ${r.message}';
  }
}

class Release {
  final String version, date;
  final List<String> items;
  const Release(this.version, this.date, this.items);
}

const List<Release> kChangelog = [
  Release('2.3', '2026/10', [
    'دعم أكثر من مزود للذكاء الاصطناعي: Claude وChatGPT وGemini وأي مزود متوافق مع OpenAI.',
    'زر جلب قائمة النماذج المتاحة واختبار الاتصال.',
    'قسم «حول التطبيق» ومشاركة التطبيق.',
    'التحقق من التحديثات وتنزيلها وتثبيتها من داخل التطبيق.',
    'توقيع ثابت للتطبيق لتجنب خطأ «تتعارض مع حزمة حالية» في التحديثات القادمة.',
  ]),
  Release('2.2', '2026/10', [
    'ترويسة مطابقة للامتحانات الرسمية مع الشعار والبسملة وبيانات المدرسة.',
    'أسئلة الاختيار من متعدد بعدة بنود، وفروع (أ، ب، ج) بدرجات، وعناوين الأقسام.',
    'أنواع أسئلة خاصة بكل مادة.',
    'استخراج النص من الصور واستيراد أسئلة كاملة من صورة بالذكاء الاصطناعي.',
    'توليد الإجابات النموذجية ونسخة المدرس.',
    'قص المخططات والخرائط من الكاميرا أو المعرض.',
    'إطار الورقة والعلامة المائية.',
    'قسم المحفوظات: فتح ومشاركة وحذف، مع التراجع والإعادة.',
    'اسم مدرس المادة في الصفحة الأخيرة.',
  ]),
  Release('2.0', '2026/10', [
    'إعادة بناء البرنامج بالكامل بواجهة حديثة وانتقالات سلسة.',
    'معاينة بحجم A4 وتصدير PDF وWord وطباعة.',
    'الثيمات (فاتح، داكن، راحة العين) وألوان التطبيق.',
    'اختيار مجلد حفظ الملفات، والترقيم التلقائي، وتنسيق الخط واللون.',
  ]),
];
